﻿using Logger;
using Microsoft.Extensions.Configuration;
using Models;
using RestSharp;

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net;

namespace WebAPIHelper
{
    public class CommonHelper: ICommonHelper
    {
        #region APP CONFIGURATION SETTINGS
        private readonly Uri ServiceURL = null;
        private readonly string APIAuthToken = string.Empty;
        private readonly string getAddressAPIKey = string.Empty;
        IConfiguration config = null;
        #endregion


        public CommonHelper(IConfiguration configuration)
        {
            config = configuration;
            ServiceURL = new Uri(configuration.GetValue<string>("ServiceURL"));
            APIAuthToken = configuration.GetValue<string>("LocalUserHostAddress");
            getAddressAPIKey = configuration.GetValue<string>("LocalUserHostAddress");

        }

        

        #region GET ADDRESSES BY POSTALCODE - api.getaddress.io

        /// <summary>
        /// GET : ADDRESSES BY POSTALCODE - {https://api.getaddress.io/}
        /// </summary>
        public string GetAddressesByPostalCode(string postalCode)
        {
            try
            {
                RestClient client = new RestClient("https://api.getaddress.io/");
                RestRequest request = new RestRequest("find/" + postalCode, Method.GET);
                request.AddHeader("api-key", getAddressAPIKey);
                var response = client.Execute(request);

                if (response.StatusCode == HttpStatusCode.OK)
                    return response.Content;
                else
                    return "";
            }
            catch (Exception ex)
            {
                ErrorLog.Error(ex.Message, typeof(CommonHelper).Name, "GetAddressesByPostalCode");
                return "";
            }
        }

        #endregion

        #region GEO LOCATION - api.ipstack.com       

        /// <summary>
        /// GET : GEO LOCATION - {http://api.ipstack.com/}
        /// </summary>
        public string GetGeoLocation(string IPAddress)
        {
            var geoLocationApiKey = config.GetValue<string>("GEOLocationAPIKey"); 
            try
            {
                RestClient client = new RestClient("http://api.ipstack.com/");
                RestRequest request = new RestRequest(IPAddress + "?access_key=" + geoLocationApiKey, Method.GET);
                var response = client.Execute(request);

                if (response.StatusCode == HttpStatusCode.OK)
                    return response.Content;
                else
                    return "";
            }
            catch (Exception ex)
            {
                ErrorLog.Error(ex.Message, typeof(CommonHelper).Name, "GetGeoLocation");
                return "";
            }
        }
        #endregion

        #region GET ADDRESSES FROM EQUIFAX AND DUMP IN DB

        /// <summary>
        /// GET : ADDRESSES FROM EQUIFAX BY POSTALCODE - {Address/Search/PostalCode}
        /// </summary>
        public AddressListModel GetAddressesFromEquiFaxByPostalCode(string postalCode)
        {
            try
            {
                RestClient client = new RestClient(ServiceURL);
                RestRequest request = new RestRequest("Address/Search/" + postalCode, Method.GET);
                IRestResponse<AddressListModel> response = client.Execute<AddressListModel>(request);

                if (response.StatusCode == HttpStatusCode.OK)
                    return response.Data;
                else if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    AddressListModel model = new AddressListModel();
                    model.Message = "UNAUTHORIZED";
                    return model;
                }
                else
                    return new AddressListModel();
            }
            catch (Exception ex)
            {
                ErrorLog.Error(ex.Message, typeof(CommonHelper).Name, "GetAddressesFromEquiFaxByPostalCode");
                return new AddressListModel();
            }
        }

        /// <summary>
        /// DUMP CUSTOMERS ADDRESS IN DB
        /// </summary>
        public void SaveAddressList(List<AddressModel> addressList)
        {
            try
            {
                RestClient client = new RestClient(ServiceURL);
                RestRequest request = new RestRequest("Address/New", Method.POST);
                request.AddJsonBody(addressList);

                client.ExecuteTaskAsync(request);
            }
            catch (Exception ex)
            {
                ErrorLog.Error(ex.Message, typeof(CommonHelper).Name, "Address/New");
            }
        }
        #endregion
                

        #region THIS API PREPARED FOR WEBHOOK LENDER - BAMBOO.

        /// <summary>
        /// POST: WEBHOOK API FOR BAMBOO - {Lender/Bamboo/QuoteUpdate}
        /// FOR UPDATING LOAN STATUS
        /// </summary>
        public ResponseModel LenderWebhook(BambooWebHookRequestModel model)
        {
            try
            {
                RestClient client = new RestClient(ServiceURL);
                RestRequest request = new RestRequest("Lender/Bamboo/QuoteUpdate", Method.POST);              
                request.AddJsonBody(model);
                IRestResponse<ResponseModel> response = client.Execute<ResponseModel>(request);

                if (response.StatusCode == HttpStatusCode.OK)
                    return response.Data;
                else
                    return new ResponseModel();
            }
            catch (Exception ex)
            {
                ErrorLog.Error(ex.Message, typeof(CommonHelper).Name, "Lender/Bamboo/QuoteUpdate");
                return new ResponseModel();
            }
        }
        #endregion
    }
}
