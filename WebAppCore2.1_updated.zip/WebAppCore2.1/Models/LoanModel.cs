﻿using System.Collections.Generic;

namespace Models
{
    public class LoanModel
    {
        public string LoanAppRegistrationID { get; set; }
        public string LoanApplicationID { get; set; }
        public string LoanAmount { get; set; }
        public string LoanDuration { get; set; }
        public string LoanType { get; set; }
        public string MaritalStatusID { get; set; }
        public string NumberOfDependents { get; set; }
        public string ResidentialStatusID { get; set; }
        public string NationalityID { get; set; }
        public string NationalityCode { get; set; }
        public string NationalityName { get; set; }
        public string NetMonthlyIncome { get; set; }
        public string GrossAnnualIncome { get; set; }
        public string OtherMonthlyIncome { get; set; }
        public string MonthlyMortgageRentExpense { get; set; }
        public string OtherMonthlyExpense { get; set; }
        public string NewLoanApproxEMI { get; set; }
        public string DateOfBirth { get; set; }
        public string Age { get; set; }
        public string CreditScore { get; set; }
        public string CreatedOn { get; set; }
        public string APR { get; set; }
        public string BankAccountNumber { get; set; }
        public string BankAccountName { get; set; }
        public string BankSortNumber { get; set; }
        public bool Term1Accepted { get; set; } = false;
        public bool Term2Accepted { get; set; } = false;

        public bool MarketingEmail { get; set; } = false;
        public bool MarketingPhone { get; set; } = false;
        public bool MarketingSMS { get; set; } = false;

        public string IntIPAddress { get; set; }
        public string ExtIPAddress { get; set; }
        public string GeoLocation { get; set; }

        public string LoanTypeName { get; set; }
        public string MaritalStatusName { get; set; }
        public string GenderID { get; set; }
        public string GenderName { get; set; }
        public string ResidentialStatusName { get; set; }

        public string NextPayDate { get; set; }
        public string SecondNextPayDate { get; set; }
        public string PayFrequencyID { get; set; }

        public string RefWebSiteName { get; set; } = "loantube.com";
        public string RefWebPageName { get; set; } = "app.loantube.com/Customer/LoanApplication";

        public string WebConnectRequestID { get; set; }


        public LoanModel()
        {
            LoanType = string.Empty;
            LoanAppRegistrationID = string.Empty;
            LoanApplicationID = string.Empty;
            LoanAmount = string.Empty;
            LoanDuration = string.Empty;
            DateOfBirth = string.Empty;
            Age = string.Empty;
            CreditScore = string.Empty;
            NewLoanApproxEMI = string.Empty;
            BankAccountNumber = string.Empty;
            BankAccountName = string.Empty;
            BankSortNumber = string.Empty;
            APR = string.Empty;
            CreatedOn = string.Empty;

            LoanTypeName = string.Empty;
            MaritalStatusName = string.Empty;
            GenderID = string.Empty;
            GenderName = string.Empty;
            ResidentialStatusName = string.Empty;
            NextPayDate = string.Empty;
            PayFrequencyID = string.Empty;
        }
    }

    public class LoanBasicModel
    {
        public string LoanID { get; set; }
        public string Version { get; set; }
        public string LoanTokenID { get; set; }
        public string LoanAmount { get; set; }
        public string LoanTerm { get; set; }
        public bool Status { get; set; }
        public bool IsAccepted { get; set; }
        public int LoanStatusID { get; set; }
        public string LoanStatus { get; set; }
        public List<string> LoanStatusList { get; set; } //LoanStatusList for display Loan Status Detailed.
        public string CreatedOn { get; set; }
        public string LoanType { get; set; }
        public string APR { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneNumber { get; set; }
        public string Gender { get; set; }
        public string Postcode { get; set; }
        public string MaritalStatus { get; set; }
        public string ResidentStatus { get; set; }
        public string EmploymentStatus { get; set; }
        public string ProductName { get; set; }
        public string CampaignName { get; set; }
        public int MonthlyIncome { get; set; }
        public int OtherMonthlyIncome { get; set; }
        public int MonthlyRent { get; set; }
        public int OtherMonthlyExpense { get; set; }
        public string MonthlyRepaymentAmount { get; set; }
        public string Remark { get; set; }
        public List<string> RemarksList { get; set; }
        public bool IsEditable { get; set; } = false;
        public string RefWebsiteName { get; set; }
        public string RefWebpageName { get; set; } //Added New

        public string AcceptedLenderName { get; set; }
        public string AcceptedLenderRefNumber { get; set; }
        public int GrossAnnualIncome { get; set; }
        public string DateOfBirth { get; set; }
        public string CustomerIPAddress { get; set; }
        public string CustomerGeoLocation { get; set; }
        public bool ShowPhoneEmail { get; set; }
        public string LenderProductType { get; set; } //UNSECURED or GUARANTOR
        public string Address { get; set; }
        public string Device { get; set; }
        public string OS { get; set; }
        public string RedirectUrl { get; set; }
        public string Price { get; set; }
        public string RequestID { get; set; }
    }


    public class LoanListModel : ResponseModel
    {
        public List<LoanBasicModel> LoanList { get; set; }
        public bool ShowPhoneEmail { get; set; }

        public LoanListModel()
        {
            LoanList = new List<LoanBasicModel>();
        }
    }
}
