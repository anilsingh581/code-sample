﻿using System;
using System.Collections.Generic;

namespace Models
{
    public class LenderMatchModel : ResponseModel
    {
        public string OfferID { get; set; }
        public string RegistrationID { get; set; }
        public string LoanApplicationID { get; set; }
        public string CampaignID { get; set; }
        public string ProductName { get; set; }
        public string ProductCode { get; set; }
        public string EmailAddress { get; set; }
        public string CompanyName { get; set; }
        public string CompanyCode { get; set; }
        public string CompanyLogoUrl { get; set; } //Added New
        public string APR { get; set; }
        public bool YodleeVerificationRequired { get; set; }
        public string LenderProductType { get; set; } //UNSECURED or GUARANTOR
        public string LenderReferenceID { get; set; }
        public double LoanAmount { get; set; }
        public int LoanDuration { get; set; }
        public double EMIAmount { get; set; }
        public bool IsRealRate { get; set; }
        public List<Double> EMIAmounts { get; set; }
        public double TotalPayableAmount { get; set; }
        public string ApplicantName { get; set; }
        public string BankAccountNumber { get; set; }
        public string BankAccountName { get; set; }
        public string BankSortNumber { get; set; }
        public string LoanTypeName { get; set; }
        public string CampaignStatus { get; set; }
        public string CompanyAPIURL { get; set; }
        public string LenderToken { get; set; }
        public string ApprovalChanceText { get; set; }
        public string ExpiryTimeStamp { get; set; }
        public Int64 ExpiryTimeSeconds { get; set; }
        public string PayOutDay { get; set; }
        public double Fee { get; set; }

        public LenderMatchModel()
        {
            EMIAmounts = new List<Double>();
        }
    }
}
