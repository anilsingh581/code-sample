﻿namespace Models
{
    public class BorrowerAddressModel : AddressModel
    {
        public bool IsLatestStatus { get; set; }
        public string StayDurationInYears { get; set; }
        public string StayDurationInMonths { get; set; }
        public BorrowerAddressModel()
        {
            StayDurationInYears = string.Empty;
            StayDurationInMonths = string.Empty;
            IsLatestStatus = false;
        }
    }
}
