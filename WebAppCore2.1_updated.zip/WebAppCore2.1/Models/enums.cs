﻿namespace Models
{
      

    public static class Loanc
    {
        public const string UTF8C = "MzAwMDgX";
        public const string ZERO = "0";
        public const int TWENTY = 20;
        public const int TWENTY8 = 28;
        public const int TEN = 10;
        public const string logoPath = "/images/logo/Lenders/";
    }
}
