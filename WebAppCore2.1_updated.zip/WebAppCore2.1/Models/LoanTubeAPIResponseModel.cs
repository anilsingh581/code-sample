﻿namespace Models
{
    public class LoanTubeAPIResponseModel : ResponseModel
    {
        public string LenderName { get; set; }
        public string LenderCode { get; set; }
        public string LenderToken { get; set; }
        public string LoanTubeLoanAppID { get; set; }
        public string LenderRequestID { get; set; }
        public string LenderTrackingID { get; set; }
        public string ResponseStatus { get; set; }
        public string CustomerRedirectUrl { get; set; }
        public string ResponseMessage { get; set; }
        public string LogoUrl { get; set; }
        
    }
}
