﻿namespace Models
{
    public class ModifiedLoanApplicationModel : RequestModel
    {
        public string LoanAppID { get; set; }
        public string LoanAmount { get; set; }
        public string LoanTerm { get; set; }
        public string BankAccountNumber { get; set; }
        public string BankSortNumber { get; set; }
    }
}
