﻿
namespace Models
{
    public class MatchedLenderProductsModel
    {
        public string LenderID { get; set; }
        public string ProductCampaignID { get; set; }
        public string LenderCode { get; set; }
        public string ProductCode { get; set; }
        public string ProductID { get; set; }
        public string APIURL { get; set; }
    }
}
