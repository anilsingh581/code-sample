﻿namespace Models
{
    public class EmploymentModel
    {
        public string EmploymentIndustry { get; set; }
        public string EmployerName { get; set; }
        public string Designation { get; set; }
        public string WorkPhoneNumber { get; set; }
        public string EmploymentLengthInYears { get; set; }
        public string EmploymentLengthInMonths { get; set; }
        public string EmploymentTypeID { get; set; }
        public string OccupationTypeID { get; set; }
        public string EmploymentTypeName { get; set; }
        public string OccupationTypeName { get; set; }

        public EmploymentModel()
        {
            EmploymentIndustry = string.Empty;
            Designation = string.Empty;
            EmployerName = string.Empty;
            WorkPhoneNumber = string.Empty;
            EmploymentLengthInYears = string.Empty;
            EmploymentLengthInMonths = string.Empty;
            EmploymentTypeID = string.Empty;
            OccupationTypeID = string.Empty;
            EmploymentTypeName = string.Empty;
            OccupationTypeName = string.Empty;
        }
    }
}
