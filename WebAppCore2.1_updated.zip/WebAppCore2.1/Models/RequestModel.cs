﻿namespace Models
{
    public class RequestModel
    {
        public string RegistrationId { get; set; }
        public string RequestId { get; set; }
        public string InternalIP { get; set; }
        public string ExternalIP { get; set; }
        public string APITokenID { get; set; }
        public string Role { get; set; }
        public string PageNo { get; set; }
        public string PageSize { get; set; }


    }

}
