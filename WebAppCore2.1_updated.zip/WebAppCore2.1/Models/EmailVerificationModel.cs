﻿namespace Models
{
    public class EmailVerificationModel
    {
        public string EmailAddress { get; set; }
        public string VerificationCode { get; set; }
        public string DOB { get; set; }
    }
}
