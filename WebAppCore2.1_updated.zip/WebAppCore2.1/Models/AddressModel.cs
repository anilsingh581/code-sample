﻿namespace Models
{
    public class AddressModel
    {
        public string AddressID { get; set; }
        public string EquifaxAddressID { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string FullAddress { get; set; }
        public string PostTown { get; set; }
        public string PostCode { get; set; }

        public string HouseNumber { get; set; }
        public string HouseName { get; set; }
        public string Street1 { get; set; }
        public string Street2 { get; set; }
        public string District { get; set; }
        public string County { get; set; }
        public string City { get; set; }
        public string Country { get; set; }


        public AddressModel()
        {
            AddressID = string.Empty;
            EquifaxAddressID = string.Empty;
            AddressLine1 = string.Empty;
            AddressLine2 = string.Empty;
            FullAddress = string.Empty;
            PostTown = string.Empty;
            PostCode = string.Empty;

            HouseNumber = string.Empty;
            HouseName = string.Empty;
            Street1 = string.Empty;
            Street2 = string.Empty;
            District = string.Empty;
            City = string.Empty;
            County = string.Empty;
            Country = string.Empty;
        }
    }
}
