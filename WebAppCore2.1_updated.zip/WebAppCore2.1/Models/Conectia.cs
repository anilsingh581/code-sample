﻿namespace Models
{
    public class Conectia
    {
        public int MinLoanAmount { get; set; }
        public int MaxLoanAmount { get; set; }
        public int AvailableCashback { get; set; }
        public string TierOfferID { get; set; }
        public string LoanType { get; set; }

    }
}
