﻿angular.module("ui.EncrDecr", [])
    .factory("EncrDecr", [function () {
        var C = CryptoJS;
        return {
            set: function (keys, value) {
                var key = C.enc.Utf8.parse(keys);
                var iv = C.enc.Utf8.parse(keys);

                var encryptedvalue = C.AES.encrypt(C.enc.Utf8.parse(value.toString()), key,
                    {
                        keySize: 128 / 8,
                        iv: iv,
                        mode: C.mode.CBC,
                        padding: C.pad.Pkcs7
                    });

                return encryptedvalue.toString();
            },
            Get: function (keys, value) {
                var key = C.enc.Utf8.parse(keys);
                var iv = C.enc.Utf8.parse(keys);

                var encryptedvalue = C.AES.decrypt(value, key,
                    {
                        keySize: 128 / 8,
                        iv: iv,
                        mode: C.mode.CBC,
                        padding: C.pad.Pkcs7
                    });

                return encryptedvalue.toString(C.enc.Utf8);
            }
        };

    }]);