﻿var app = angular.module("myApp", ["ui.Services"]);

app.controller('cLoanAppFilterResult', ["$scope", "$rootScope", "ControllerService", "$timeout", "customerResultConstant", "$window", '$interval', '$filter', '$copyToClipboard', function ($scope, $rootScope, ControllerService, $timeout, customerResultConstant, $window, $interval, $filter, $copyToClipboard) {
    var svm = $scope;
    var rsvm = $rootScope;
    svm.isApplicationProcessed = false;
    svm.isResubmit = false;
    svm.MatchData = [];
    svm.MatchedLenderList = [];
    svm.WaitForResultRecall = 5;
    svm.showProgressBar = false;
    svm.recallForResultfound = false;
    svm.hidePageTitle = false;
    svm.loanMatchedFound = false;
    svm.DeclinedLenders = [];
    svm.UnMatchedLenders = [];
    svm.modifyLoanBtnDefaultTxt = true;
    svm.deeplinkUrl = "";

    svm.copyRowModal = false;
    svm.copyRowsModal = false;
    //rsvm.buttonClicked = ""; open if needed copy titile

    //Default modify loan model
    svm.ResubmitLoanApp = {
        LoanAppID :"",
        LoanAmount: "",
        LoanTerm: "",
        BankAccountNumber: "",
        BankSortNumber: ""
    }

    //Loan terms array/list
    svm.LoanTerms = [
        { ID: 4, Term: '12', TermText: '12 months' },
        { ID: 5, Term: '18', TermText: '18 months' },
        { ID: 6, Term: '24', TermText: '2 years' },
        { ID: 7, Term: '36', TermText: '3 years' },
        { ID: 8, Term: '48', TermText: '4 years' },
        { ID: 9, Term: '60', TermText: '5 years' },
        { ID: 10, Term: '72', TermText: '6 years' },
        { ID: 11, Term: '84', TermText: '7 years' }
    ];

    //Loan purpose/type array/list
    svm.LoanType = [
        { ID: 1, Name: "Holiday" },
        { ID: 2, Name: "Car Loan" },
        { ID: 3, Name: "Debt Consolidation" },
        { ID: 4, Name: "Home Improvement" },
        { ID: 5, Name: "Other" }
    ];

    svm.changeLoanTerms = function () {
        svm.checkLoanTerm(svm.ResubmitLoanApp.LoanTerm);
    }

    svm.IsMobile = false;
    svm.IsResultMobileView = function () {
        if (isMobile.any())
            svm.IsMobile = true;

        //UPDATE THE META TAG FROM HEADER
        updateMetaTag('viewport');
    }

    svm.showLoanDetailInfo = function (loanID, grpName) {
        showMoreInfoSection(loanID, grpName);
    }

    svm.ModifyLoanBoxResultFlag = false;
    svm.modifyLoanBoxOpen = function () {
        svm.ModifyLoanBoxResultFlag = true;
    }

    svm.modifyLoanBoxClose = function () {
        svm.ModifyLoanBoxResultFlag = false;
        svm.IsValidForModify = false;//default message display
    }

    //STEP3 - DISPALY LENDERS QUOTES and RESULT
    //GET FINAL MATCH RESULT FOR LOAN APPLICATION

    //Progressbar Params
    var countAwaitingOffer = 0;
    svm.maxDuration = 20000; // seconds
    svm.ProgressBarCount = 0;
    svm.ProgressBarWidth = 5;

    //LAUNCH THE LOAN APPLICATION RESULTS.
    svm.loadAppLoanResult = function (loanAppId) {  
        //debugger;
        if (loanAppId != undefined && loanAppId != null && loanAppId != "") {
            rsvm.ResultLoanAppId = loanAppId;
            svm.loanAppMatchStatusResult(loanAppId);
        }
    }

    //RESULT APIS REQUEST CALL
    svm.loanAppMatchStatusResult = function (loanAppId) {
        //SET AUTHENTICATOIN TOKEN 
        var request = {};
        if (typeof (Storage) !== "undefined") {
            request.Role = localStorage.getItem("Key4");
            request.APITokenID = localStorage.getItem("Key2");
            request.InternalIP = localStorage.getItem("Key3");
        }
       
        //ShowLoanAppDialog();     
        var data = { LoanApplicationId: loanAppId }

        ControllerService.Post(
            "/Customer/GetLoanApplicationResult", data, function (status, responseData) {
                HideLoanAppDialog();
                if (status && responseData.Status == false) {
                    unauthorizedaccess(svm);
                }
                else if (responseData.Status == false && responseData.ReturnValue ==="MzAwMDgX") {
                    unauthorizedaccess(svm);
                }
                else if (responseData.Status) {
                    //Close modify showProgressBar
                    clearInterval(dealInterval);
                    svm.modifyLoanBoxClose();
                    svm.modifyLoanBtnDefaultTxt = true;//Reset as default text

                    //T.UK REDIRECT URL
                    if (responseData.RedirectUrl != null) {
                        //T.UK REDIRECT URL
                        tukRedirectURL(responseData);
                    }
                    else {
                        //END T.UK
                        svm.isApplicationProcessed = true;
                        svm.recallForResultfound = true;
                        svm.MatchData = responseData;
                        var resultLen = responseData.MatchedLenderList.length;
                        svm.loanMatchedFound = resultLen != 0 ? true : false;
                        svm.hidePageTitle = resultLen != 0 ? true : false;

                        svm.MatchedLenderList = responseData.MatchedLenderList;
                        svm.MatchStatus = responseData.MatchStatus;
                        svm.IsUpdatableLoan = responseData.IsUpdatable;

                        //alert(checkIsAgent());
                        if (checkIsAgent())
                            svm.IsAgentFilled = responseData.IsAgentFilled; //true|false

                        //In case where there is no Unsecured Personal Loan offer, show message below Your results.
                        displayMsgIfNoUnsecuredPLOffer(svm, responseData);

                        //USED FOR DISPLAY LOAN APPLICATION RESULT AND WEBCONNECT REQUEST ALSO
                        var { loanID, lAmount } = getLoanAmountNTerms(svm, responseData);

                        //USED FOR DISPLAY DECLINED AND UNMATCHED LENDERS
                        svm.DeclinedLenders = responseData.DeclinedLenders;
                        svm.UnMatchedLenders = responseData.UnMatchedLenders;
                    }

                    //RESET AFTER RE-CALL API                      
                    if (responseData.AwaitingOffers != null) {
                        countAwaitingOffer = timeoutAwaitingOffers(countAwaitingOffer, svm, $timeout, rsvm, parseInt(svm.WaitForResultRecall), $interval, responseData.AwaitingOffers);
                    }
                    else {
                        svm.showProgressBar = false;
                        svm.recallForResultfound = true;
                    }
                    //End - Re-call API
                }
            });
    }

    function checkIsAgent() {
        var flag = false;
        if (typeof (Storage) !== "undefined") {
            var agentByEmail = localStorage.getItem("agentByEmail");
            flag = agentByEmail == null ? false : true;
        }
        return flag;
    }

    svm.loanJsonObject = function (jsonObj) {
        if (jsonObj != undefined && jsonObj != null)
            return JSONParse(jsonObj);
    }
    //END - VALIDATE RESUBMIT FORM FLAGS
    
    //Set the date we're counting down Deals or offer
    svm.endDealsTimer = function (date, ids, grpName) {
        endDealsTimer(date, ids, grpName);
    }

    //RESUBMIT
    //SRATS - VALIDATE RESUBMIT FORM FLAGS
    svm.IsResubmitLoanAmountRequired = false;
    svm.IsValidForModify = false;

    //Check The LoanAmount and Multiples of As pre you.
    svm.multiplesOfLoanAmount = function () {
        svm.IsResubmitLoanAmountRequired = false;
        var loanAmount = svm.ResubmitLoanApp.LoanAmount;

        if (loanAmount != undefined && loanAmount != null) {
            var calAmount = parseInt(loanAmount) / parseInt(customerResultConstant.MultiplesOfInLoanAmount);
            var amount = parseInt(calAmount) * parseInt(customerResultConstant.MultiplesOfInLoanAmount);
            svm.ResubmitLoanApp.LoanAmount = amount;
        }
        else {
            svm.IsResubmitLoanAmountRequired = true;
        }
    }

    svm.checkMaxLoanAmount = function () {
        svm.exceedsLoanAmountLimit = false;
        var amount = svm.ResubmitLoanApp.LoanAmount;
        if (amount > customerResultConstant.MaxLoanAmount) {
            svm.exceedsLoanAmountLimit = true;
            svm.ResubmitLoanApp.LoanAmount = null;
        }
        else if (amount < customerResultConstant.MinLoanAmount && amount > 0) {
            $scope.exceedsLoanAmountLimit = true;
            svm.ResubmitLoanApp.LoanAmount = null;
        }
        else if (amount == 0) {
            svm.ResubmitLoanApp.LoanAmount = null;
        }
    }
    //END - VALIDATE RESUBMIT FORM FLAGS        

    //Load thease method on dom init
    //render default at init
    svm.initMethods = function (app_token) { 
        if (app_token != undefined && app_token != null && app_token != "") {
            renderLogo(svm, rsvm);
            svm.IsResultMobileView(); 
            svm.loadAppLoanResult(app_token);
        }

        //getSetRequestToken(svm);      
    }

    svm.modifyLoan = function () {
        if (angular.equals(svm.ResultLoanAmount, svm.ResubmitLoanApp.LoanAmount) &&
            angular.equals(svm.ResultLoanDuration + "", svm.ResubmitLoanApp.LoanTerm + "")) {
            svm.IsValidForModify = true;
            return false;
        } else {
            svm.IsValidForModify = false;
        }
    }

    //IS USED TO BIND THE MODIFY LOAN APPLICATION ON RESULT PAGE.
    svm.ModfyLoanData = function (e) {
        e.preventDefault();
        if (svm.modifyLoanForm.$invalid) {
            angular.forEach(svm.modifyLoanForm.$error, function (field) {
                angular.forEach(field, function (errorField) {
                    errorField.$setTouched();
                });
            });
            return false;
        }

        //Check and Validate form items are change
        if (angular.equals(svm.ResultLoanAmount, svm.ResubmitLoanApp.LoanAmount) &&
            angular.equals(svm.ResultLoanDuration + "", svm.ResubmitLoanApp.LoanTerm + "")) {
            svm.IsValidForModify = true;
            return false;
        }        

        svm.modifyLoanBtnDefaultTxt = false;

        //SET AUTHENTICATOIN TOKEN FOR PREMATCH LOAN STATUSRESULT.
        var request = {};
        svm.ResubmitLoanApp.LoanAppID = rsvm.ResultLoanAppId;
        
        if (typeof (Storage) !== "undefined") {
            request.Role = localStorage.getItem("Key4");
            request.APITokenID = localStorage.getItem("Key2");
            request.InternalIP = localStorage.getItem("Key3");
        }
        var loanData = { LoanAppID: svm.ResubmitLoanApp.LoanAppID, LoanAmount: svm.ResubmitLoanApp.LoanAmount, LoanTerm: svm.ResubmitLoanApp.LoanTerm };
        var data = JSON.stringify(loanData);

        ControllerService.Post(
            "/Customer/ResubmitLoanApplication", data, function (status, responseData) {
                HideLoanAppDialog();                
                
                if (status && responseData.Status == false) {
                    var msg = responseData.Message != null ? responseData.Message : customerResultConstant.SomsomethingWentWrong;
                    ShowError("Loan Application", msg);
                }
                else if (responseData.Status) {
                    //SET AUTHENTICATOIN TOKEN & REDIRECT ON OFFERS
                    redirectToOffers(generateNumber(10) + responseData.ReturnValue + JSSecretKey);
                }
            });
    }

    //END RESUBMIT

    //Accept Loan section
    var acceptedId, acceptedGrpname, conectiaOfferID;
    svm.acceptQuotes = function (obj, rowId, grpName) {
        //console.log(obj);
        //LOG THE API FOR ANOTHER PROCESS.
        if (obj !== undefined && obj != null) {
            acceptedId = rowId;
            acceptedGrpname = grpName;          
            if (obj.LenderProductType == "SECURED") {
                AsyncAcceptLoanConfirmYesNo("Note: Your home may be repossessed if you do not keep up repayments on secured debts.", customerResultConstant.SecuredLoanOfferMsg, acceptLoanOffer, obj);
            }
            else if (obj.LenderProductType == "GUARANTOR") {
                AsyncAcceptLoanConfirmYesNo("Note: Your friend, your family member or your colleague can be your guarantor.", customerResultConstant.GuarantorLoanOffer, acceptLoanOffer, obj);
            }
            else if (obj.LenderProductType == "UNSECURED") {
                checkIsQuoteAccptedOrNot(svm, rowId, grpName);
                callLoanAgreedAPI(obj, ControllerService, customerResultConstant, svm);
            }
        }
    }

    var acceptLoanOffer = function (dataModel) {
        checkIsQuoteAccptedOrNot(svm, acceptedId, acceptedGrpname);
        callLoanAgreedAPI(dataModel, ControllerService, customerResultConstant, svm);
    }
    //Accept Loan section End

    svm.clearLocalStore = function () {
        localStorage.clear();
    }

    svm.copyResultRowToClipboard = function (e, item) {
        if (item !== undefined && item !== null) {
            let deeplinkUrl = getBaseURL() + "Customer/lender_deeplink?lender=" + item.CompanyName + "&offerId=" + item.OfferID;
            svm.copyRowModal = !$scope.copyRowModal;
            item.CompanyAPIURL = deeplinkUrl;
            svm.copyRow = item;
        }
        //if (item !== undefined && item !== null) {
        //    let deeplinkUrl = getBaseURL() + "Customer/lender_deeplink?lender=" + item.CompanyName + "&offerId=" + item.OfferID;
        //    let copyRow = {
        //        "Lender Name": item.CompanyName,
        //        "Loan": "£" + item.LoanAmount,
        //        "Loan Type": item.LenderProductType,
        //        "Monthly Repayment Amount": "£" + item.EMIAmount,
        //        "APR": item.APR,
        //        "Total Repayable Amount": "£" + item.TotalPayableAmount,
        //        "[Get this Loan]": deeplinkUrl
        //    }
        //    $copyToClipboard.copy(JSON.stringify(copyRow)).then(function () { });
        //}
    }

    svm.copyResultRowsToClipboard = function (e, rows) {
        svm.copyRows = []
        if (rows.length > 0) {      
            svm.copyRowsModal = !$scope.copyRowsModal;
            angular.forEach(rows, function (item, key) {
                let deeplinkUrl = getBaseURL() + "Customer/lender_deeplink?lender=" + item.CompanyName + "&offerId=" + item.OfferID;
                item.CompanyAPIURL = deeplinkUrl;

                svm.copyRows.push({
                    CompanyName: item.CompanyName,
                    LoanAmount: item.LoanAmount,
                    LoanDuration: item.LoanDuration,
                    LenderProductType: item.LenderProductType,
                    EMIAmounts: item.EMIAmounts,
                    APR: item.APR,
                    TotalPayableAmount: item.TotalPayableAmount,
                    CompanyAPIURL: deeplinkUrl
                });
            });
        }
        //var copyItems = [];
        //if (rows.length > 0) {
        //    angular.forEach(rows, function (item, key) {
        //        let deeplinkUrl = getBaseURL() + "Customer/lender_deeplink?lender=" + item.CompanyName + "&offerId=" + item.OfferID;
        //        copyItems.push({
        //            "Lender Name": item.CompanyName,
        //            "Loan": "£"+ item.LoanAmount,
        //            "Loan Type": item.LenderProductType,
        //            "Monthly Repayment Amount": "£" + item.EMIAmount,
        //            "APR": item.APR,
        //            "Total Repayable Amount": "£" + item.TotalPayableAmount,
        //            "[Get this Loan](": deeplinkUrl+")"
        //        });
        //    }, copyItems);
        //    $copyToClipboard.copy(JSON.stringify(copyItems)).then(function () { });
        //}
    }

    //DOB 
    svm.Day = "";
    svm.Month = "";
    svm.Year = "";
    svm.validDay = true;
    svm.Message = "";
    svm.MessageInvalidAge = "";
    svm.IsNotAuthorisedRequest = false;
    svm.IsNotAuthorisedMsg = "";

    svm.CheckValidDay = function () {
        //VALIDATE THE DOB
        if (svm.Day == "" || svm.Month == "" || svm.Year == "") {
            svm.validDay = true;
            return;
        }

        var DOB = svm.Day + "/" + svm.Month + "/" + svm.Year;

        svm.Borrower.DOB = DOB;
        if (!isValidDate(DOB)) {
            svm.validDay = false;
            svm.MessageInvalidAge = customerResultConstant.InvalidDate;
            return false;
        }
        else {
            var startdate = ConvertToJSDate(DOB);
            var enddate = GetCurrentJSDate();
            var diffDays = DateDifference(startdate, enddate);
            var year = parseInt(diffDays / 365);

            if (year < 18) {
                svm.validDay = false;
                svm.MessageInvalidAge = customerResultConstant.AgeShould18Year;
                return false;
            }
            svm.validDay = true;
            return true;
        }
    }

    //This method used after email link and validate.
    svm.VerifyYourLoanRequest = function (e) {
        e.preventDefault();

        svm.IsNotAuthorisedRequest = false;
        svm.IsNotAuthorisedMsg = "";

        if (svm.verifyLoanRequest.$invalid) {
            angular.forEach(svm.verifyLoanRequest.$error, function (field) {
                angular.forEach(field, function (errorField) {
                    errorField.$setTouched();
                });
            });
            return false;
        }

        var request = {};
        if (typeof (Storage) !== "undefined") {
            request.Role = localStorage.getItem("Key4");
            request.APITokenID = localStorage.getItem("Key2");
            request.InternalIP = localStorage.getItem("Key3");
        }
        request.LoanApplicationID = token2;
        request.Token = token1;
        request.LastName = svm.Borrower.LastName;
        request.DateOfBirth = svm.Day + "/" + svm.Month + "/" + svm.Year;// Customer DateOfBirth - DOB

        if (typeof (Storage) !== "undefined") {
            localStorage.setItem("token3", svm.Borrower.LastName);
            localStorage.setItem("token4", svm.Day + "/" + svm.Month + "/" + svm.Year);
        }
        ShowLoanAppDialog();
        //var data = JSON.stringify(request);
        ControllerService.Post(
            "/Customer/ValidateViewLoanApplication", request , function (status, responseData) {
                $timeout(function () { HideLoanAppDialog(); }, 1000);
                if (status && responseData.Status == false) {
                    var msg = responseData.Message != null ? responseData.Message : customerResultConstant.SomsomethingWentWrong;

                    //NOT AUTHORISED REQUEST
                    svm.IsNotAuthorisedRequest = true;
                    svm.IsNotAuthorisedMsg = msg;
                }
                else if (responseData.Status) {                   
                    //SET AUTHENTICATOIN TOKEN & REDIRECT ON OFFERS
                    redirectToOffers(generateNumber(10) + responseData.ReturnValue + JSSecretKey);
                    //END METHOD
                }
            });
    }

    svm.IsMobileView = function () {
        if (isMobile.any())
            svm.IsMobile = true;
    }

    svm.toggleRealRate = function (grpName, index) {
        $("#realRate" + grpName + index).toggle();
    }

    svm.IsDealExpiredYear = null;
    svm.checkIsDealExpired = function (date) {
        svm.IsDealExpiredYear = getFullYear(date);     
    }

    svm.isValid = function (value) {
        if (value === undefined || value === "" || value === null ) {
            return false;
        }
        return true;
    }
}]);

app.constant("customerResultConstant", (function () {
    return {
        UNAUTHORIZED_401: "Authorization Required.",
        OK_200: "Success",
        EXPECTATION_FAILED_417: "Something went wrong while processing your request. Please try again or contact us for assistance.",
        BAD_REQUEST_400: "The server cannot or will not process the request due to an apparent client error.",
        INTERNAL_SERVER_ERROR_500: "Something went wrong while processing your request. Please try again or contact us for assistance.",
        FORBIDDEN_403: "Something went wrong while processing your request. Please try again or contact us for assistance.",
        NOTFOUND_404: "Something went wrong while processing your request. Please try again or contact us for assistance.",
        METHOD_NOT_ALLOWED_405: "Something went wrong while processing your request. Please try again or contact us for assistance.",
        REQUEST_TIMEOUT_408: "The server timed out waiting for the request. The client did not produce a request within the time that the server was prepared to wait.",
        UNKNOWN_ERROR_520: "Something went wrong while processing your request. Please try again or contact us for assistance.",
        InvalidDate: "Invalid date.",
        AgeShould18Year: "Age should be greater than 18.",
        SomsomethingWentWrong: "Something went wrong while processing your request. Please try again or contact us for assistance.",
        RefreshLoanApp: "sorry! it seems you tried to refresh the page. you cannot resubmit the same loan.",
        ReDirectURL: "https://www.loantube.com/",
        MultiplesOfInLoanAmount: 50,
        CustomerCallMsg: "We are unable to find you a lender from our panel on this occasion. However, our partner Friends Capital may be able to help with an alternative Homeowner Loan. ",
        bamboo: "BAMBOO",
        shawbrook: "SHAWBROOK",
        progressive: "PROGRESSIVE",
        moneyplatform: "MONEYPLATFORM",
        ukcredit: "UKCREDIT",
        loanReject: "Customer/LoanReject",
        unauthorized: "UNAUTHORIZED",
        webconnectURL: "https://mywebconect.com/p.ashx?o=1523&e=310&f=pb&r=",
        StatusAccepted: 'Accepted',
        MaxLoanAmount: 35000,
        MinLoanAmount: 1000,
        SecuredLoanOfferMsg: "Your loan will be secured against your home. Are you comfortable securing this debt against your home?",
        GuarantorLoanOffer: "To get this loan, you will need to arrange someone who can become your guarantor. Do you have a Guarantor?"
    }
})());

app.directive('restrictSpecialCharactersDirective', function () {
    function link(scope, elem, attrs, ngModel) {
        ngModel.$parsers.push(function (viewValue) {
            var reg = /^[0-9]*$/;
            if (viewValue.match(reg)) {
                return viewValue;
            }
            var transformedValue = ngModel.$modelValue;
            ngModel.$setViewValue(transformedValue);
            ngModel.$render();
            return transformedValue;
        });
    }

    return {
        restrict: 'A',
        require: 'ngModel',
        link: link
    };
});

app.filter('groupBy', function ($parse) {
    return _.memoize(function (items, field) {
        var getter = $parse(field);
        return _.groupBy(items, function (item) {
            return getter(item);
        });
    });
});

app.provider('$copyToClipboard', [function () {
    this.$get = ['$q', '$window', function ($q, $window) {
        var body = angular.element($window.document.body);
        var textarea = angular.element('<textarea/>');
        textarea.css({
            position: 'fixed',
            opacity: '0'
        });
        return {
            copy: function (stringToCopy) {
                var deferred = $q.defer();
                deferred.notify("copying the text to clipboard");
                textarea.val(stringToCopy);
                body.append(textarea);
                textarea[0].select();

                try {
                    var successful = $window.document.execCommand('copy');
                    if (!successful) throw successful;
                    deferred.resolve(successful);
                } catch (err) {
                    deferred.reject(err);
                } finally {
                    textarea.remove();
                }
                return deferred.promise;
            }
        };
    }];
}]);

//PUSH WEBCONECT API FOR UPDATE THE PARTER DATA.
var pushWebconectAPI = function (loanID, lAmount, ControllerService, customerResultConstant, offerID, eventID, LenderProductType) {
    //Request Id read from Conectia URLs.
    var webConnectReqIDs = localStorage.getItem("WebConnectReqID");
    if (webConnectReqIDs != undefined && webConnectReqIDs != '' && offerID !='') {
        //UPDATE THE LOANTUBE APPLICATION - OFFERID USING LOANAPPLICATIONID AND CONECTIA REQUESTID.
        var agreement = {};
        agreement.LoanApplicationID = loanID;
        agreement.LenderReferenceID = webConnectReqIDs + "-" + offerID;
        agreement.LoanEMIAmount = lAmount;
        agreement.LenderProductType = LenderProductType;
        agreement.LenderToken = eventID;

        //SET AUTHENTICATOIN TOKEN 
        if (typeof (Storage) !== "undefined") {
            agreement.Role = localStorage.getItem("Key4");
            agreement.APITokenID = localStorage.getItem("Key2");
            agreement.InternalIP = localStorage.getItem("Key3");
        }

        //console.log(agreement);
        var dataModel = JSON.stringify(agreement);
        ControllerService.Post("/Customer/UpdateConectiaRequest", dataModel, function (status, responseData) {
            window.localStorage.removeItem("WebConnectReqID");
            console.log("Update Conectia Request Is : " + status);
        });
        //END -UPDATE THE LOANTUBE APPLICATION        
    }
}

//Log conectia    
var logConectia = function (data, ControllerService, customerResultConstant) {
    //console.log(data.LenderProductType);
    var offerID, eventID = "";
    if (data != undefined && data != null) {
        var result = [];
        if (data.LenderProductType === 'GUARANTOR') {
            result = filterConectiaItems(conectia_GuarantorLoan, data.LoanAmount);
            offerID = result[0].TierOfferID;
            eventID = result[0].EventID;
        }
        else if (data.LenderProductType === 'UNSECURED') {
            result = filterConectiaItems(conectia_PersonalLoan, data.LoanAmount);
            offerID = result[0].TierOfferID;
            eventID = result[0].EventID;
        }

        //Push conectia
        if (offerID != undefined && offerID != "") {
            pushWebconectAPI(data.LoanApplicationID, data.LoanAmount, ControllerService, customerResultConstant, offerID, eventID, data.LenderProductType);
        }
    }
    //return offerID;
}

//RECALL APIS UNTILL THE AWAITINGOFFERS = 0
var timeoutAwaitingOffers = function (count, svm, $timeout, rsvm, waitTime, $interval, awaitingOffers) {
    count++;
    svm.showProgressBar = true;

    //alert(svm.ProgressBarWidth);
    stop = $interval(function () {
        svm.ProgressBarCount += 1000;
        svm.ProgressBarWidth = Math.min(parseInt((svm.ProgressBarCount / svm.maxDuration) * 100), 100.0);
        if (svm.ProgressBarWidth > 80) {
            svm.ProgressBarWidth = 80;
        }
    }, 1000);

    var cancelTimeout = $timeout(function () { svm.loanAppMatchStatusResult(rsvm.ResultLoanAppId); }, (count == 1) ? 1 : waitTime * 1000); // 5 seconds

    if (awaitingOffers == 0) {
        $timeout.cancel(cancelTimeout);
        $interval.cancel(stop);
        svm.showProgressBar = false;
        svm.recallForResultfound = true;
    }
    return count;
}


var getLoanAmountNTerms = function (svm, responseData) {
    var loanID = 0, lAmount = 0; //PUSH WEB CONECT API
    svm.ResultLoanAmount = responseData.LoanAmount;
    svm.ResultLoanDuration = responseData.LoanDuration;

    //set default loan amount for Modify loan
    svm.ResubmitLoanApp.LoanTerm = responseData.LoanDuration + "";
    svm.ResubmitLoanApp.LoanAmount = responseData.LoanAmount;

    //PUSH WEB CONECT API
    loanID = parseInt(responseData.ReturnValue);
    lAmount = responseData.LoanAmount;

    return { loanID, lAmount };
}

//HELPER FUNCTION:START
var ShowError = function (header, error) {
    $("#showErrorModal .modal-title").html(header)
    $("#showErrorModal .modal-msg").html(error)
    $("#showErrorModal").modal();
}

var callLoanAgreedAPI = function (obj, ControllerService, customerResultConstant, svm) {
    //OPEN WINDOW/TAB
   // var newWindow = window.open('', '_blank');
   // newWindow.location = "/Customer/lender_deeplink?lender=" + obj.CompanyName+"&offerId=" + obj.OfferID;
   
    var deeplinkUrl = "/Customer/lender_deeplink?lender=" + obj.CompanyName + "&offerId=" + obj.OfferID;
  
    //$("#deeplinkOpener")[0].click();
    var deeplink = document.createElement('a');     
    deeplink.href = deeplinkUrl;
    deeplink.target = "_blank";
    document.body.appendChild(deeplink);
    deeplink.click();

    document.body.removeChild(deeplink);

    logConectia(obj, ControllerService, customerResultConstant);      
}

var showMoreInfoSection = function (loanID, grpName) {
    $("#dtl" + grpName + loanID).toggle();
    $("#infoBtn" + grpName + loanID).toggleClass("closeInfo");
    var ldsId = $("#lda" + grpName + loanID);
    ldsId.text() == "more info" ? ldsId.text("close info") : ldsId.text("more info");
}

var checkIsQuoteAccptedOrNot = function (svm, id, grpName) {
    var ids2 = id + 'Q' + grpName;  
    $('#' + ids2).addClass("pointernone").text("Accepted");
}

var displayMsgIfNoUnsecuredPLOffer = function (svm, responseData) {
    svm.IsUnsecuredLoanFound = false;
    if (responseData.MatchedLenderList.filter(function(e) {
    if (e.LenderProductType === 'UNSECURED')
        return e;
    }).length > 0) {
        svm.IsUnsecuredLoanFound = true;
    }

    //Check AwaitingOffers: 0
    svm.AwaitingOffers = responseData.AwaitingOffers;
    console.log(svm.AwaitingOffers);
}

var renderLogo = function (svm, rsvm) {
    svm.IsMobileView();
    if (svm.IsMobile) {
        rsvm.lendingLogoURL = "/images/customer/resultMobSmallLogo.png";
    }
}


var unauthorizedaccess = function (svm) {
    svm.recallForResultfound = true;
    svm.SomsomethingWentWrong = true;
}

var uuid4=function () {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}