﻿var app = angular.module("myApp", ["ui.Services"]);

app.constant("customerConstant", (function () {
    return {
        UNAUTHORIZED_401: "Authorization Required.",
        OK_200: "Success",
        EXPECTATION_FAILED_417: "Something went wrong while processing your request. Please try again or contact us for assistance.",
        BAD_REQUEST_400: "The server cannot or will not process the request due to an apparent client error.",
        INTERNAL_SERVER_ERROR_500: "Something went wrong while processing your request. Please try again or contact us for assistance.",
        FORBIDDEN_403: "Something went wrong while processing your request. Please try again or contact us for assistance.",
        NOTFOUND_404: "Something went wrong while processing your request. Please try again or contact us for assistance.",
        METHOD_NOT_ALLOWED_405: "Something went wrong while processing your request. Please try again or contact us for assistance.",
        REQUEST_TIMEOUT_408: "The server timed out waiting for the request. The client did not produce a request within the time that the server was prepared to wait.",
        UNKNOWN_ERROR_520: "Something went wrong while processing your request. Please try again or contact us for assistance.",
        InvalidDate: "Invalid date.",
        InvalidPayDate:"Invalid pay date.",
        AgeShould18Year: "Age should be greater than 18.",
        SelLoanType: "Select the Loan Type.",
        SelEmploymentType: "Select the Employment Type.",
        SelIncomBenefit: "Select at least one income benefit.",
        SelFinancialExpenses: "Select at least one financial expenses.",
        SelHousingType: "Select the Housing Type.",
        Last3YearAddress: "Please provide the last 3 year address details.",
        SelAddress: "Please select your address.",
        YearOfCurrentAddress: "Year at current address is required.",
        MonthOfCurrentAddress: "Month at current address is required.",
        TitleLoanAppResult: "Available Offers",
        TitleLoanApp: "Loan Application",
        YodleeMsg: "Some issue with Yodlee interface, please try later.",
        SomsomethingWentWrong: "Something went wrong while processing your request. Please try again or contact us for assistance.",
        DefaultGender: "",
        MultiplesOfInLoanAmount: 50,
        UK786loans: "786loans.uk",
        UK786loansLogo: "/images/logo/lt_partner/786loans.png",
        LoanBroker: "loan-broker.uk",
        LoanBrokerLogo: "/images/logo/lt_partner/LoanBrokerLogo.png",
        OysterLoan: "oysterloan.co.uk",
        OysterLoanLogo: "/images/logo/lt_partner/OysterLoanlogo.png",
        LoanPrincess: "loan-princess.uk",
        LoanPrincessLogo: "/images/logo/lt_partner/LoanPrincesslogo.png",
        SuggestionStartAmount: 250,
        SuggestionEndAmount: 1000,
        MaxLoanAmount: 35000,
        MinLoanAmount: 1000
    }
})());

app.controller('cBorrower', ["$scope", "$rootScope", "ControllerService", "$timeout", "customerConstant", "$window", "$filter", function ($scope, $rootScope, ControllerService, $timeout, customerConstant, $window) {
    var svm = $scope;
    $rootScope.navigation = "loan";

    svm.sortType = ''; // set the default sort type
    svm.sortReverse = false;  // set the default sort order
    svm.searchFish = '';     // set the default search/filter term
    svm.color = '';
    svm.PostalCode = "";
    svm.StepNumber = 0;
    svm.StepVisited = 0;
    svm.MatchedLenderList = [];
    svm.IsSubmitLoanApp = false;
    svm.EquiFaxAddressNotFound = true;
    svm.emailPattern = /^[a-zA-Z]+[a-zA-Z0-9._-]+@[a-zA-Z]+\.[a-zA-Z.]{2,5}$/;
    svm.EmploymentYear = "";
    svm.AddressFound = true;
    svm.isValidAddress = true;
    svm.isAddressComplete = true;
    svm.ShowPopulatedAddress = false;
    svm.BorrowerAddresses = [];
    svm.AddressList = [];
    svm.JSSecretKey = JSSecretKey;
    svm.isApplicationSaved = false;
    svm.isEmailVerified = false;
    svm.isPhoneVerified = false;
    svm.isApplicationProcessed = false;
    svm.Term1Accepted = false;
    svm.Term2Accepted = false;
    svm.ErrorMsg = "";
    svm.LoanApplicationId = "";
    svm.editLoanApplicationID = 0;
    svm.LoanApproved = false;
    svm.AgreeTerms = false;
    svm.filterlenderFeature = "";
    svm.signature = "typeSig";
    svm.typeSignature = "";
    svm.SignatureFileName = "";
    svm.RepaymentDate = "";
    svm.Address = {};
    svm.totalResidentialMonths = 0;
    var APITokenID = "";
    var IPAddress = "";
    var Role = "";

    //List of loan terms
    svm.LoanTerms = [
        { ID: 4, Term: '12', TermText: '12 months' },
        { ID: 5, Term: '18', TermText: '18 months' },
        { ID: 6, Term: '24', TermText: '2 years' },
        { ID: 7, Term: '36', TermText: '3 years' },
        { ID: 8, Term: '48', TermText: '4 years' },
        { ID: 9, Term: '60', TermText: '5 years' },
        { ID: 10, Term: '72', TermText: '6 years' },
        { ID: 11, Term: '84', TermText: '7 years' }
    ];

    svm.changeLoanTerms = function () {
        svm.visitedLoanDuration = true;
        svm.check0InLoanTerm();
        svm.checkLoanAmounForTheMoneyPlatform();
    }

    //List of Nationalities
    $scope.Nationalities =
        [{NationalityID: 1, CountryCode: 'GB', Nationality: 'British' },
        { NationalityID: 2, CountryCode: 'AF', Nationality: 'Afghan' },
        { NationalityID: 3, CountryCode: 'AL', Nationality: 'Albanian' },
        { NationalityID: 4, CountryCode: 'DZ', Nationality: 'Algerian' },
        { NationalityID: 5, CountryCode: 'US', Nationality: 'American' },
        { NationalityID: 6, CountryCode: 'AD', Nationality: 'Andorran' },
        { NationalityID: 7, CountryCode: 'AO', Nationality: 'Angolan' },
        { NationalityID: 8, CountryCode: 'AM', Nationality: 'Armenian' },
        { NationalityID: 9, CountryCode: 'AT', Nationality: 'Austrian' },
        { NationalityID: 10, CountryCode: 'AZ', Nationality: 'Azerbaijani' },
        { NationalityID: 11, CountryCode: 'AR', Nationality: 'Argentinian' },
        { NationalityID: 12, CountryCode: 'AU', Nationality: 'Australian' },
        { NationalityID: 13, CountryCode: 'BH', Nationality: 'Bahraini' },
        { NationalityID: 14, CountryCode: 'BD', Nationality: 'Bangladeshi' },
        { NationalityID: 15, CountryCode: 'BB', Nationality: 'Barbadian' },
        { NationalityID: 16, CountryCode: 'BY', Nationality: 'Belarusian' },
        { NationalityID: 17, CountryCode: 'BZ', Nationality: 'Belizean' },
        { NationalityID: 18, CountryCode: 'BJ', Nationality: 'Beninese' },
        { NationalityID: 19, CountryCode: 'BM', Nationality: 'Bermudian' },
        { NationalityID: 20, CountryCode: 'BT', Nationality: 'Bhutanese' },
        { NationalityID: 21, CountryCode: 'BO', Nationality: 'Bolivian' },
        { NationalityID: 22, CountryCode: 'BA', Nationality: 'Bosnian' },
        { NationalityID: 23, CountryCode: 'BW', Nationality: 'Botswanan' },
        { NationalityID: 24, CountryCode: 'GB', Nationality: 'British' },
        { NationalityID: 25, CountryCode: 'BG', Nationality: 'Bulgarian' },
        { NationalityID: 26, CountryCode: 'BF', Nationality: 'Burkinese' },
        { NationalityID: 27, CountryCode: 'BI', Nationality: 'Burundian' },
        { NationalityID: 28, CountryCode: 'CA', Nationality: 'Canadian' },
        { NationalityID: 29, CountryCode: 'CN', Nationality: 'Chinese' },
        { NationalityID: 30, CountryCode: 'CO', Nationality: 'Colombian' },
        { NationalityID: 31, CountryCode: 'CU', Nationality: 'Cuban' },
        { NationalityID: 32, CountryCode: 'KH', Nationality: 'Cambodian' },
        { NationalityID: 33, CountryCode: 'CM', Nationality: 'Cameroonian' },
        { NationalityID: 34, CountryCode: 'CV', Nationality: 'Cape Verdean' },
        { NationalityID: 35, CountryCode: 'TD', Nationality: 'Chadian' },
        { NationalityID: 36, CountryCode: 'CL', Nationality: 'Chilean' },
        { NationalityID: 37, CountryCode: 'CG', Nationality: 'Congolese' },
        { NationalityID: 38, CountryCode: 'CR', Nationality: 'Costa Rican' },
        { NationalityID: 39, CountryCode: 'HR', Nationality: 'Croat' },
        { NationalityID: 40, CountryCode: 'CY', Nationality: 'Cypriot' },
        { NationalityID: 41, CountryCode: 'CZ', Nationality: 'Czech' },
        { NationalityID: 42, CountryCode: 'DK', Nationality: 'Danish' },
        { NationalityID: 43, CountryCode: 'DO', Nationality: 'Dominican' },
        { NationalityID: 44, CountryCode: 'DJ', Nationality: 'Djiboutian' },
        { NationalityID: 45, CountryCode: 'DM', Nationality: 'Dominican' },
        { NationalityID: 46, CountryCode: 'NL', Nationality: 'Dutch' },
        { NationalityID: 47, CountryCode: 'EC', Nationality: 'Ecuadorean' },
        { NationalityID: 48, CountryCode: 'EG', Nationality: 'Egyptian' },
        { NationalityID: 49, CountryCode: 'ER', Nationality: 'Eritrean' },
        { NationalityID: 50, CountryCode: 'EE', Nationality: 'Estonian' },
        { NationalityID: 51, CountryCode: 'ET', Nationality: 'Ethiopian' },
        { NationalityID: 52, CountryCode: 'FJ', Nationality: 'Fijian' },
        { NationalityID: 53, CountryCode: 'FI', Nationality: 'Finnish' },
        { NationalityID: 54, CountryCode: 'PF', Nationality: 'French Polynesian' },
        { NationalityID: 55, CountryCode: 'FR', Nationality: 'French' },
        { NationalityID: 56, CountryCode: 'GA', Nationality: 'Gabonese' },
        { NationalityID: 57, CountryCode: 'GM', Nationality: 'Gambian' },
        { NationalityID: 58, CountryCode: 'GE', Nationality: 'Georgian' },
        { NationalityID: 59, CountryCode: 'DE', Nationality: 'German' },
        { NationalityID: 60, CountryCode: 'GT', Nationality: 'Guatemalan' },
        { NationalityID: 61, CountryCode: 'GH', Nationality: 'Ghanaian' },
        { NationalityID: 62, CountryCode: 'GR', Nationality: 'Greek' },
        { NationalityID: 63, CountryCode: 'GD', Nationality: 'Grenadian' },
        { NationalityID: 64, CountryCode: 'GN', Nationality: 'Guinean' },
        { NationalityID: 65, CountryCode: 'GY', Nationality: 'Guyanese' },
        { NationalityID: 66, CountryCode: 'HT', Nationality: 'Haitian' },
        { NationalityID: 67, CountryCode: 'HN', Nationality: 'Honduran' },
        { NationalityID: 68, CountryCode: 'HU', Nationality: 'Hungarian' },
        { NationalityID: 69, CountryCode: 'IN', Nationality: 'Indian' },
        { NationalityID: 70, CountryCode: 'IE', Nationality: 'Ireland' },
        { NationalityID: 71, CountryCode: 'IL', Nationality: 'Israeli' },
        { NationalityID: 72, CountryCode: 'IT', Nationality: 'Italian' },
        { NationalityID: 73, CountryCode: 'IS', Nationality: 'Icelandic' },
        { NationalityID: 74, CountryCode: 'ID', Nationality: 'Indonesian' },
        { NationalityID: 75, CountryCode: 'IR', Nationality: 'Iranian' },
        { NationalityID: 76, CountryCode: 'IQ', Nationality: 'Iraqi' },
        { NationalityID: 78, CountryCode: 'JP', Nationality: 'Japanese' },
        { NationalityID: 79, CountryCode: 'JM', Nationality: 'Jamaican' },
        { NationalityID: 80, CountryCode: 'JO', Nationality: 'Jordanian' },
        { NationalityID: 81, CountryCode: 'KZ', Nationality: 'Kazakh' },
        { NationalityID: 82, CountryCode: 'KE', Nationality: 'Kenyan' },
        { NationalityID: 83, CountryCode: 'KP', Nationality: 'North Korean' },
        { NationalityID: 84, CountryCode: 'KW', Nationality: 'Kuwaiti' },
        { NationalityID: 85, CountryCode: 'LV', Nationality: 'Latvian' },
        { NationalityID: 86, CountryCode: 'LB', Nationality: 'Lebanese' },
        { NationalityID: 87, CountryCode: 'LR', Nationality: 'Liberian' },
        { NationalityID: 88, CountryCode: 'LY', Nationality: 'Libyan' },
        { NationalityID: 89, CountryCode: 'LT', Nationality: 'Lithuanian' },
        { NationalityID: 90, CountryCode: 'LU', Nationality: 'LUXEMBOURG' },
        { NationalityID: 91, CountryCode: 'MG', Nationality: 'Madagascan' },
        { NationalityID: 92, CountryCode: 'MW', Nationality: 'Malawian' },
        { NationalityID: 93, CountryCode: 'MY', Nationality: 'Malaysian' },
        { NationalityID: 94, CountryCode: 'MV', Nationality: 'Maldivian' },
        { NationalityID: 95, CountryCode: 'ML', Nationality: 'Malian' },
        { NationalityID: 96, CountryCode: 'MT', Nationality: 'Maltese' },
        { NationalityID: 97, CountryCode: 'MR', Nationality: 'Mauritanian' },
        { NationalityID: 98, CountryCode: 'MU', Nationality: 'Mauritian' },
        { NationalityID: 99, CountryCode: 'MC', Nationality: 'Monacan' },
        { NationalityID: 100, CountryCode: 'MN', Nationality: 'Mongolian' },
        { NationalityID: 101, CountryCode: 'ME', Nationality: 'Montenegrin' },
        { NationalityID: 102, CountryCode: 'MA', Nationality: 'Moroccan' },
        { NationalityID: 103, CountryCode: 'MZ', Nationality: 'Mozambican' },
        { NationalityID: 104, CountryCode: 'MX', Nationality: 'Mexican' },
        { NationalityID: 105, CountryCode: 'NA', Nationality: 'Namibian' },
        { NationalityID: 106, CountryCode: 'NP', Nationality: 'Nepalese' },
        { NationalityID: 107, CountryCode: 'NZ', Nationality: 'New Zealand' },
        { NationalityID: 108, CountryCode: 'NI', Nationality: 'Nicaraguan' },
        { NationalityID: 109, CountryCode: 'NE', Nationality: 'Nigerien' },
        { NationalityID: 110, CountryCode: 'NG', Nationality: 'Nigerian' },
        { NationalityID: 111, CountryCode: 'NO', Nationality: 'Norwegian' },
        { NationalityID: 112, CountryCode: 'OM', Nationality: 'Omani' },
        { NationalityID: 113, CountryCode: 'PK', Nationality: 'Pakistani' },
        { NationalityID: 114, CountryCode: 'PA', Nationality: 'Panamanian' },
        { NationalityID: 115, CountryCode: 'PG', Nationality: 'Guinean' },
        { NationalityID: 116, CountryCode: 'PY', Nationality: 'Paraguayan' },
        { NationalityID: 117, CountryCode: 'PE', Nationality: 'Peruvian' },
        { NationalityID: 118, CountryCode: 'PH', Nationality: 'Philippine' },
        { NationalityID: 119, CountryCode: 'PL', Nationality: 'Polish' },
        { NationalityID: 120, CountryCode: 'PT', Nationality: 'Portuguese' },
        { NationalityID: 121, CountryCode: 'QA', Nationality: 'Qatari' },
        { NationalityID: 122, CountryCode: 'RO', Nationality: 'Romanian' },
        { NationalityID: 123, CountryCode: 'RW', Nationality: 'Rwandan' },
        { NationalityID: 124, CountryCode: 'SV', Nationality: 'Salvadorean' },
        { NationalityID: 125, CountryCode: 'AS', Nationality: 'Samoan' },
        { NationalityID: 126, CountryCode: 'SA', Nationality: 'Saudi Arabian' },
        { NationalityID: 127, CountryCode: 'SN', Nationality: 'Senegalese' },
        { NationalityID: 128, CountryCode: 'RS', Nationality: 'Serbian' },
        { NationalityID: 129, CountryCode: 'SL', Nationality: 'Sierra Leonian' },
        { NationalityID: 130, CountryCode: 'SG', Nationality: 'Singaporean' },
        { NationalityID: 131, CountryCode: 'SK', Nationality: 'Slovak' },
        { NationalityID: 132, CountryCode: 'SI', Nationality: 'Slovenian' },
        { NationalityID: 133, CountryCode: 'SB', Nationality: 'Slomoni' },
        { NationalityID: 134, CountryCode: 'SO', Nationality: 'Somali' },
        { NationalityID: 135, CountryCode: 'ZA', Nationality: 'South African' },
        { NationalityID: 136, CountryCode: 'KR', Nationality: 'South Korean' },
        { NationalityID: 137, CountryCode: 'ES', Nationality: 'Spanish' },
        { NationalityID: 138, CountryCode: 'SE', Nationality: 'Swedish' },
        { NationalityID: 139, CountryCode: 'CH', Nationality: 'Swiss' },
        { NationalityID: 140, CountryCode: 'LK', Nationality: 'Sri Lankan' },
        { NationalityID: 141, CountryCode: 'SD', Nationality: 'Sudanese' },
        { NationalityID: 142, CountryCode: 'SR', Nationality: 'Surinamese' },
        { NationalityID: 143, CountryCode: 'SZ', Nationality: 'Swazi' },
        { NationalityID: 144, CountryCode: 'TW', Nationality: 'Taiwanese' },
        { NationalityID: 145, CountryCode: 'TJ', Nationality: 'Tajik' },
        { NationalityID: 146, CountryCode: 'TH', Nationality: 'Thai' },
        { NationalityID: 147, CountryCode: 'TG', Nationality: 'Togolese' },
        { NationalityID: 148, CountryCode: 'TT', Nationality: 'Trinidadian' },
        { NationalityID: 149, CountryCode: 'TN', Nationality: 'Tunisian' },
        { NationalityID: 150, CountryCode: 'TR', Nationality: 'Turkish' },
        { NationalityID: 151, CountryCode: 'TM', Nationality: 'Turkoman' },
        { NationalityID: 152, CountryCode: 'TV', Nationality: 'Tuvaluan' },
        { NationalityID: 153, CountryCode: 'UG', Nationality: 'Ugandan' },
        { NationalityID: 154, CountryCode: 'UA', Nationality: 'Ukrainian' },
        { NationalityID: 155, CountryCode: 'AE', Nationality: 'Emirati' },
        { NationalityID: 156, CountryCode: 'VE', Nationality: 'Venezuelan' },
        { NationalityID: 157, CountryCode: 'VN', Nationality: 'Vietnamese' },
        { NationalityID: 158, CountryCode: 'UY', Nationality: 'Uruguayan' },
        { NationalityID: 159, CountryCode: 'UZ', Nationality: 'Uzbek' },
        { NationalityID: 160, CountryCode: 'VU', Nationality: 'Vanuatuan' },
        { NationalityID: 161, CountryCode: 'YE', Nationality: 'Yemeni' },
        { NationalityID: 162, CountryCode: 'ZM', Nationality: 'Zambian' }];

    //List of loantype
    $scope.LoanType = [
        { ID: 1, Name: "Holiday" },
        { ID: 2, Name: "Car Loan" },
        { ID: 3, Name: "Debt Consolidation" },
        { ID: 4, Name: "Home Improvement" },
        { ID: 5, Name: "Other" }
    ];

    //List of Employment Type
    $scope.EmploymentType = [
        { ID: 1, Name: "Employed-Full Time" },
        { ID: 2, Name: "Self-Employed" },
        { ID: 3, Name: "On Benefits" },
        { ID: 4, Name: "Employed-Part Time" },
        { ID: 5, Name: "Unemployed" },
        { ID: 6, Name: "Retired" },
        { ID: 7, Name: "Home-maker" },
        { ID: 8, Name: "Student" }
    ];

    //List of Pay Frequency
    $scope.PayFrequency = [
        { ID: 1, Name: "Weekly" },
        { ID: 2, Name: "Fortnightly" },
        { ID: 3, Name: "Four weekly" },
        { ID: 4, Name: "Monthly" }
    ];

    //List of Housing Type
    $scope.HousingType = [
        { ID: 1, Name: "Home Owner (Mortgaged)" },
        { ID: 2, Name: "Home Owner (Mortgage Free)" },
        { ID: 3, Name: "Unfurnished Tenant" },
        { ID: 4, Name: "Furnished Tenant" },
        { ID: 5, Name: "Living with Parent(s)" },
        { ID: 6, Name: "Council Tenant" },
        { ID: 7, Name: "Other" }
    ];

    //List of Marital Stutus
    $scope.MaritalStutusList = [
        { ID: 1, Name: "Married" },
        { ID: 2, Name: "Living with Partner" },
        { ID: 3, Name: "Single" },
        { ID: 4, Name: "Separated" },
        { ID: 5, Name: "Divorced" },
        { ID: 6, Name: "Widowed" },
        { ID: 7, Name: "Other" }
    ];

    //List of Occupations
    $scope.Occupations = [
        { ID: 1, Name: "Managerial" },
        { ID: 2, Name: "Professional" },
        { ID: 3, Name: "Semi-professional/Technical" },
        { ID: 4, Name: "Clerical/Administration" },
        { ID: 5, Name: "Skilled Trade" },
        { ID: 6, Name: "Care/Leisure/Service" },
        { ID: 7, Name: "Sales/Customer Service" },
        { ID: 8, Name: "Process/Machine Operative" },
        { ID: 9, Name: "Other" }
    ];

    //List of Employmet
    $scope.EmploymentIndustries = [
        { ID: 1, Name: "Accountancy" },
        { ID: 2, Name: "Administration/Secretarial" },
        { ID: 3, Name: "Advertising/Media" },
        { ID: 4, Name: "Business Consultancy" },
        { ID: 5, Name: "Banking/Insurance" },
        { ID: 6, Name: "Call Centre Operations" },
        { ID: 7, Name: "Civil Service" },
        { ID: 8, Name: "Cleaning Services" },
        { ID: 9, Name: "Computer Services" },
        { ID: 10, Name: "Construction" },
        { ID: 11, Name: "Driver" },
        { ID: 12, Name: "Education" },
        { ID: 13, Name: "Electricity/Gas/Water" },
        { ID: 14, Name: "Finance" },
        { ID: 15, Name: "Health" },
        { ID: 16, Name: "Hotels/Restaurants" },
        { ID: 17, Name: "Insurance" },
        { ID: 18, Name: "Labour" },
        { ID: 19, Name: "Legal Services" },
        { ID: 20, Name: "Leisure/Culture" },
        { ID: 21, Name: "Manager mid level" },
        { ID: 22, Name: "Manager senior level" },
        { ID: 23, Name: "Manufacturing" },
        { ID: 24, Name: "Military" },
        { ID: 25, Name: "Mining/Quarrying" },
        { ID: 26, Name: "Professional" },
        { ID: 27, Name: "Public Administration" },
        { ID: 28, Name: "Publishing" },
        { ID: 29, Name: "Real Estate/Property" },
        { ID: 30, Name: "Research/Development" },
        { ID: 31, Name: "Supermarket/Retail" },
        { ID: 32, Name: "Sales and Customer Service" },
        { ID: 33, Name: "Skilled trade" },
        { ID: 34, Name: "Utilities/Telecom" },
        { ID: 35, Name: "Transportation" },
        { ID: 36, Name: "Other" }
    ];

    //List of Lender Search Keys
    $scope.LendersSearchKeys = [{
        Id: 1,
        checked: false,
        name: "LowestTotal payable"
    }, {
        Id: 2,
        checked: false,
        name: "No Admin Fee"
    },
    {
        Id: 7,
        checked: false,
        name: "Deferred Payments Allowed"
    },
    {
        Id: '4',
        checked: false,
        name: "Lowest monthly installment"
    }, {
        Id: 5,
        checked: false,
        name: "No Early Redemption Fees"
    }, {
        Id: 6,
        checked: false,
        name: "Payment Holidays Allowed"
    }, {
        Id: 3,
        checked: false,
        name: "Lowest APR"
    }];

    $scope.ShowLoanDetails = function (loanId) {
        $scope.SelectedLoanId = loanId;
        $scope.ShowDetails = true;
        var request = {};
        if (typeof (Storage) !== "undefined") {
            request.Role = localStorage.getItem("Key4");
            request.APITokenID = localStorage.getItem("Key2");
            request.InternalIP = localStorage.getItem("Key3");
        }
        request.RequestId = loanId;
        ShowDialog();
        ControllerService.Post(
            "/Customer/GetLoanApplicationDetails", { obj: request },
            function (status, responseData) {
                HideDialog();
                if (status && responseData.Status) {
                    $scope.Borrower = responseData;
                }                
            });
    }

    $scope.GetBorrowerTemplate = function (loanApplicationId) {
        $scope.LoanApplicationTitle = customerConstant.TitleLoanApp;

        //get term and amount from local storage
        if (typeof (Storage) !== "undefined") {
            Role = localStorage.getItem("Key4");
            APITokenID = localStorage.getItem("Key2");
            IPAddress = localStorage.getItem("Key3");
            var term = localStorage.getItem("LoanTerm");
            var amount = localStorage.getItem("LoanAmount");
            var refWebSiteName = localStorage.getItem("RefWebSiteName");
            var refWebPageName = localStorage.getItem("RefWebPageName");
            var webConnectReqID = localStorage.getItem("ReqID");
            var agentID = localStorage.getItem("agentID");
            //For conectia
            localStorage.setItem("WebConnectReqID", webConnectReqID);

            //clear the value of amount, term, ref site and page
            localStorage.removeItem('LoanTerm');
            localStorage.removeItem('LoanAmount');
            localStorage.removeItem('RefWebSiteName');
            //localStorage.removeItem('RefWebPageName');
        }
        ControllerService.Get(
            "/Customer/GetBorrowerTemplate", { LoanApplicationId: loanApplicationId },
            function (status, responseData) {
                HideDialog();
                if (status) {
                    $scope.Borrower = responseData;
                    $scope.Borrower.Gender = customerConstant.DefaultGender;
                    $scope.Borrower.LoanApplicationDetail.LoanAmount = (amount != undefined && amount.length > 0) ? parseInt(amount) : null;
                    $scope.Borrower.LoanApplicationDetail.LoanDuration = (term != undefined && term.length > 0) ? parseInt(term) + "" : null;

                    //Validate loan amount ! > 35K, If yes set blank and set info message.
                    $scope.checkMaxLoanAmount();

                    //START - Check URL UTM tems is exists in our terms dropdown then select it default otherwise pic to select item.
                    svm.utlTermsFlag = false;
                    angular.forEach(svm.LoanTerms, function (item) {
                        if (svm.Borrower.LoanApplicationDetail.LoanDuration === item.Term)
                            svm.utlTermsFlag = true;
                    });
                    svm.Borrower.LoanApplicationDetail.LoanDuration = svm.utlTermsFlag === false ? "" : svm.Borrower.LoanApplicationDetail.LoanDuration;
                    //END

                    $scope.Borrower.LoanApplicationDetail.RefWebSiteName = refWebSiteName;
                    $scope.Borrower.LoanApplicationDetail.RefWebPageName = refWebPageName;
                    $scope.Borrower.LoanApplicationDetail.WebConnectRequestID = webConnectReqID;

                    //For Ajent User display
                    //this is temprary, will improve in future
                    if (refWebPageName === agentID) {
                        svm.Agent = true;
                    }

                    //FOR REFRENCE SITE LOGO URL REPLACEMENT
                    setlendingLogoURL(refWebSiteName, customerConstant, $rootScope);

                    //For display Suggestion Msg on Loan Amount and terms (250-1000/18)
                    //svm.loanTermsSuggestionMsgDisplay();

                    svm.multiplesOfLoanAmount(); //Check The LoanAmount and Multiples of As pre you.
                    svm.checkLoanAmounForTheMoneyPlatform(); //Enable Disable Account Number and Short code fields


                    $scope.Term1Accepted = responseData.LoanApplicationDetail.Term1Accepted;
                    $scope.Term2Accepted = responseData.LoanApplicationDetail.Term2Accepted;
                    $scope.BorrowerAddresses = angular.copy(responseData.ResidentAddress);

                    //Check to enable and disable postal code and lookup address.
                    $scope.checkTotalResidentialYears();
                }
            });
    };

    //Helper Function:START
    function ShowError(header, error) {
        $("#showErrorModal .modal-title").html(header)
        $("#showErrorModal .modal-msg").html(error)
        $("#showErrorModal").modal();
    }

    function TotalIncome() {
        var arr = document.getElementsByName('income');
        var tot = 0;
        if (arr != undefined) {
            for (var i = 0; i < arr.length; i++) {
                if (parseInt(arr[i].value))
                    tot += parseInt(arr[i].value);
            }
        }
        tot = (tot == 0) ? "" : tot;
        return tot;
    }

    function TotalExpense() {
        var arr = document.getElementsByName('expense');
        var tot = 0;
        if (arr != undefined) {
            for (var i = 0; i < arr.length; i++) {
                if (parseInt(arr[i].value))
                    tot += parseInt(arr[i].value);
            }
        }
        tot = (tot == 0) ? "" : tot;
        return tot;
    }

    function isCurrentAddressAdded() {
        var isCurrentAddressExist = false;
        angular.forEach($scope.BorrowerAddresses, function (add) {
            if (add.IsLatestStatus) {
                isCurrentAddressExist = true;
            }
        });
        return isCurrentAddressExist;
    }

    //This method is used to calculate the total residential years and converted in months.
    $scope.checkTotalResidentialYears = function () {
        var m1 = 0, m2 = 0;
        if (svm.BorrowerAddresses != undefined && svm.BorrowerAddresses != null && svm.BorrowerAddresses.length > 0) {
            angular.forEach($scope.BorrowerAddresses, function (val) {
                if (val.StayDurationInYears !== undefined && val.StayDurationInYears !== null) {
                    m1 = m1 + (parseInt(val.StayDurationInYears) * 12);
                }

                if (val.StayDurationInMonths !== undefined && val.StayDurationInMonths !== null) {
                    m2 = m2 + parseInt(val.StayDurationInMonths);
                }
            });
        }
        $scope.totalResidentialMonths = m1 + m2;
    }

    function ValidateBorrowerAddress() {
        if (svm.BorrowerAddresses != undefined && svm.BorrowerAddresses != null && svm.BorrowerAddresses.length == 0) {
            svm.ErrorMsg = customerConstant.Last3YearAddress;
            svm.isValidAddress = false;
            svm.IsEnableRequiredMsg = true; s
            return false;
        }
        svm.isValidAddress = true;
        return true;
    }
    //Helper Function:End

    //Angular Helper Function:START
    svm.SelectAddress = function () {
        var EquifaxAddressID = angular.copy(svm.Address.EquifaxAddressID);
        if (svm.Addresses != undefined) {
            for (i = 0; i < svm.Addresses.length; i++) {
                if (svm.Addresses[i].EquifaxAddressID == EquifaxAddressID) {
                    svm.Address = angular.copy(svm.Addresses[i]);
                    break;
                }
            }
        }
    }

    svm.AddressYearnMonth = "";
    $scope.AddAddress = function () {
        if ($scope.Address.EquifaxAddressID == undefined) {
            $scope.AddressYearnMonth = customerConstant.SelectAddress;
            return false;
        }

        if ($scope.AddressYear == undefined || $scope.AddressYear == "" || $scope.AddressYear == null) {
            $scope.AddressYearnMonth = customerConstant.YearOfCurrentAddress;
            return false;
        } else if ($scope.AddressMonth == undefined || $scope.AddressMonth == "" || $scope.AddressMonth == null) {
            $scope.AddressYearnMonth = customerConstant.MonthOfCurrentAddress;
            return false;
        } else {
            $scope.AddressYearnMonth = "";
        }

        if ($scope.Address.EquifaxAddressID == undefined) {
            $scope.isAddressComplete = false;
        }
        else {
            $scope.isAddressComplete = true;
        }

        if ($scope.isAddressComplete == false) {
            return;
        }

        //SET ADDRESS COMPONENTS
        $scope.Address.StayDurationInYears = ($scope.AddressYear != undefined && $scope.AddressYear != '') ? $scope.AddressYear : 0;
        $scope.Address.StayDurationInMonths = ($scope.AddressMonth != undefined && $scope.AddressMonth != '') ? $scope.AddressMonth : 0;

        $scope.BorrowerAddresses.push($scope.Address);
        $scope.Address = {};
        $scope.ShowPopulatedAddress = false;

        $scope.AddressMonth = "";
        $scope.AddressYear = "";
        $scope.IsEnableRequiredMsg = false;

        //UNSELECT THE SELECTED ADDRESS
        $("#AddressList option:selected").prop('selected', false);
        $scope.checkTotalResidentialYears();
    }

    $scope.ResetAddressYearnMonth = function () {
        $scope.AddressYearnMonth = "";
        $scope.AddressYear = "";
        $scope.AddressMonth = "";
    }

    svm.RemoveAddress = function (AddressId) {
        if (svm.BorrowerAddresses != undefined) {
            for (var i = 0; i < svm.BorrowerAddresses.length; i++) {
                if (svm.BorrowerAddresses[i].AddressID == AddressId) {
                    svm.BorrowerAddresses.splice(i, 1);
                    break;
                }
            }
        }
        svm.checkTotalResidentialYears();
    }

    $scope.CalculateTotalIncome = function () {
        $scope.Borrower.LoanApplicationDetail.TotalIncome = TotalIncome();
    }

    $scope.CalculateTotalExpense = function () {
        $scope.Borrower.LoanApplicationDetail.TotalExpense = TotalExpense();
    }
    //END - ANGULAR HELPER FUNCTION

    svm.searchAddressOnPostCodeKeyUp = function (falg) {
        if (svm.PostalCode != undefined && svm.PostalCode.length >= 6) {
            svm.GetBorrowerAddresses();
        }
    }

    svm.setAddressWidth = function (items) {
        var falg = false;
        if (items !== undefined && items !== null) {
            falg = items.length > 0 ? true : false;
        }
        //alert(falg);
        return falg;
    }

    //USED TO GET BORROWER ADDRESSES FROM EQUIFAX
    $scope.GetBorrowerAddresses = function () {
        if ($scope.PostalCode.length >= 6) {
            ShowDialog();
            ControllerService.Get(
                "/Customer/GetBorrowerAddressesFromEquifaxAsync", { PostalCode: $scope.PostalCode }, function (status, responseData) {
                    HideDialog();
                    if (responseData.AddressList != null) {
                        $scope.AddressFound = (responseData.AddressList.length > 0) ? true : false;
                        if ($scope.AddressFound == true) {
                            $scope.ShowPopulatedAddress = true;
                            $scope.Addresses = responseData.AddressList;
                            $scope.Address = {};
                            $scope.EquiFaxAddressNotFound = true;

                            //SET DEFAULT DATE(TILL DATE) FOR CURRENT ADDRESS
                            if (isCurrentAddressAdded() == false) {
                                $scope.StayedTill = GetCurrentDate();
                                $scope.MaxStatyedTill = $scope.StayedTill;
                            }

                            //SET TILL DATE TO PREVIOUS ADDRESS FROM DATE
                            var addresscount = $scope.BorrowerAddresses.length;
                            if (addresscount > 0 && isCurrentAddressAdded() == true) {
                                $scope.StayedTill = $scope.BorrowerAddresses[addresscount - 1].StayedFrom;
                                $scope.MaxStatyedTill = $scope.StayedTill;
                            }
                        }
                        else {
                            $scope.EquiFaxAddressNotFound = false;
                            $scope.ShowPopulatedAddress = true;

                            //RESET MODEL IF EQUIFAX ADDRESS NOT FOUND
                            resetModelIfEquifaxAddressNotFound();
                        }
                    }
                    else {
                        $scope.EquiFaxAddressNotFound = false;
                        $scope.ShowPopulatedAddress = true;

                        //RESET MODEL IF EQUIFAX ADDRESS NOT FOUND
                        resetModelIfEquifaxAddressNotFound();
                    }
                });            
        }
    };

    //RESET MODEL IF EQUIFAX ADDRESS NOT FOUND
    var resetModelIfEquifaxAddressNotFound = function () {
        $scope.Address.HouseNumber = null;
        $scope.Address.HouseName = null;
        $scope.Address.Street1 = null;
        $scope.Address.PostTown = null;
        $scope.Address.District = null;
    }

    $scope.setLoanApplicationIds = function (loanID) {
        $scope.editLoanApplicationID = loanID;
    }

    $scope.redirectToLoans = function () {
        window.location.href = "/Customer/Index";
    }

    svm.ResultLoanTypeName = "";
    svm.ResultLoanAmount = 0;
    svm.ResultLoanDuration = 0;
    svm.IsLoanTypeRequired = false;
    svm.IsResidentialStatusRequired = false;
    svm.IsMaritalStatusRequired = false;
    svm.IsEmploymentTypeRequired = false;
    svm.IsOccupationTypeRequired = false;

    function validateDDL(id) {
        if (id != undefined && id != null && id == 0) {
            return false;
        }
        return true;
    }

    $scope.validateLoanType = function () {
        $scope.IsLoanTypeRequired = false;
    }

    $scope.MonthlyRentValueShouldBeGreaterThanZero = false;
    $scope.ResidentialStatus = function (id) {
        $scope.IsResidentialStatusRequired = false;
        $scope.MonthlyRentValueShouldBeGreaterThanZero = false;
        $scope.IsMonthlyRentValueShouldBeGreaterThanZero = true;

        //
        if (id == 1 || id == 3 || id == 4) {
            $scope.MonthlyRentValueShouldBeGreaterThanZero = true;
            $scope.checkandValidateMonthlyRentValue($scope.Borrower.LoanApplicationDetail.MonthlyMortgageRentExpense);
        }
    }

    $scope.IsMonthlyRentValueShouldBeGreaterThanZero = true;
    $scope.checkandValidateMonthlyRentValue = function (val) {
        if ($scope.MonthlyRentValueShouldBeGreaterThanZero) {
            $scope.IsMonthlyRentValueShouldBeGreaterThanZero = true;
            if (val == 0) {
                $scope.IsMonthlyRentValueShouldBeGreaterThanZero = false;
            }
        }
    }

    $scope.MaritalStatus = function () {
        $scope.IsMaritalStatusRequired = false;
    }

    $scope.EmploymentTypeVal = function (val) {
        $scope.IsEmploymentTypeRequired = false;
        var yearField = $('#employmentLengthInYears');
        var monthField = $('#employmentLengthInMonths');

        yearField.attr('readonly', false);
        monthField.attr('readonly', false);


        var empTypeId = $scope.Borrower.EmployerDetail.EmploymentTypeID;
        //THIS IS THE CUSTOM RULE FOR UI DISPLAY
        //IF 3 THEN "ON BENEFITS", IF 5 THEN "UNEMPLOYED", IF 6 THEN "RETIRED" IF 7 THEN "HOME-MAKER", IF 8 THEN "STUDENT".
        if (empTypeId == 3 || empTypeId == 5 || empTypeId == 6 || empTypeId == 7 || empTypeId == 8) {
            $scope.Borrower.EmployerDetail.EmploymentLengthInYears = 0
            $scope.Borrower.EmployerDetail.EmploymentLengthInMonths = 0
            $scope.Borrower.EmployerDetail.OccupationTypeID = 9;// OccupationTypeID == 9 MEANSE THE OCCUPATIONS IS OTHER TYPE.

            yearField.attr('readonly', true);
            monthField.attr('readonly', true);
        }
        else {
            $scope.Borrower.EmployerDetail.OccupationTypeID = "";
            $scope.Borrower.EmployerDetail.EmploymentLengthInYears = "";
            $scope.Borrower.EmployerDetail.EmploymentLengthInMonths = "";
        }
    }

    $scope.OccupationType = function () {
        $scope.IsOccupationTypeRequired = false;
    }

    svm.IsGenderRequired = false;
    svm.IsNextPayDateRequired = false;
    var valiNextPayDate = function () {
        var control = $("#nextPayDate");
        svm.IsNextPayDateRequired = true;
        if (control != undefined && control != null) {
            if (control.val().length == 10) {
                svm.IsNextPayDateRequired = false;
                return true;
            }
        }
        return false;
    }

    var focusOnDTP = function () {
        var control = $("#nextPayDate");
        if (control != undefined && control != null) {
            control.focus().addClass("ng-invalid ng-invalid-required ng-touched");
        }
    }

    svm.validateNextPayDate = function () {
        var dateControl = $("#nextPayDate");
        svm.IsNextPayDateRequired = true;
        if (dateControl != undefined && dateControl != null) {
            if (dateControl.val().length == 10) {
                svm.IsNextPayDateRequired = false;
                dateControl.focusout().removeClass("ng-invalid ng-invalid-required ng-touched");
            }
        }
    }

    var scrollIntoAppView = function () {
        var elm = $('input.ng-invalid, select.ng-invalid');
        if (elm.length) {
            $(window).scrollTop(elm.offset().top - 134);
            elm.first().focus();
        }
    }

    $scope.IsInValidGrossAnnualIncome = false;
    $scope.validateGrossAnnualIncom = function (flag) {
        var nmi = $scope.Borrower.LoanApplicationDetail.NetMonthlyIncome;
        var gai = $scope.Borrower.LoanApplicationDetail.GrossAnnualIncome;

        var calGAIAprox = 12 * nmi;
        if (gai != null) {
            if (gai >= calGAIAprox) {
                $scope.IsInValidGrossAnnualIncome = false;
            }
            else {
                $scope.IsInValidGrossAnnualIncome = true;
                if (flag) {
                    $window.document.getElementById('ga_Income').focus();
                }
            }
        }
    }

    $scope.fillGrossAnnualIncomTextBox = function () {
        $scope.IsInValidGrossAnnualIncome = false;
    }

    //Check The LoanAmount and Multiples of As pre you.
    $scope.multiplesOfLoanAmount = function () {
        var loanAmount = $scope.Borrower.LoanApplicationDetail.LoanAmount;
        if (loanAmount != undefined && loanAmount != null) {
            var calAmount = parseInt(loanAmount) / parseInt(customerConstant.MultiplesOfInLoanAmount);
            $scope.Borrower.LoanApplicationDetail.LoanAmount = parseInt(calAmount) * parseInt(customerConstant.MultiplesOfInLoanAmount);
        }
    }

    var remove0atFirstCharPosition = function (val) {
        while (val.substring(0, 1) === '0') {   //First character is a '0'.
            val = val.substring(1);             //Trim the leading '0'
        }
        return val;
    }

    $scope.check0InLoanTerm = function () {
        var term = $scope.Borrower.LoanApplicationDetail.LoanDuration;
        $scope.Borrower.LoanApplicationDetail.LoanDuration = remove0atFirstCharPosition(term);
    }

    $scope.check0InNetMonthlyIncome = function () {
        var mIncom = $scope.Borrower.LoanApplicationDetail.NetMonthlyIncome;
        $scope.Borrower.LoanApplicationDetail.NetMonthlyIncome = remove0atFirstCharPosition(mIncom);
    }

    $scope.check0InOtherMonthlyIncome = function () {
        var oIncom = $scope.Borrower.LoanApplicationDetail.OtherMonthlyIncome;
        $scope.Borrower.LoanApplicationDetail.OtherMonthlyIncome = parseInt(oIncom);
    }

    $scope.check0InRentExpense = function () {
        var rent = $scope.Borrower.LoanApplicationDetail.MonthlyMortgageRentExpense;
        $scope.Borrower.LoanApplicationDetail.MonthlyMortgageRentExpense = parseInt(rent);
    }

    $scope.check0InOtherMonthlyExpense = function () {
        var otherExpense = $scope.Borrower.LoanApplicationDetail.OtherMonthlyExpense;
        $scope.Borrower.LoanApplicationDetail.OtherMonthlyExpense = parseInt(otherExpense);
    }

    $scope.checkMaxLoanAmount = function () {
        $scope.exceedsLoanAmountLimit = false;
        var amount = $scope.Borrower.LoanApplicationDetail.LoanAmount;
        if (amount > customerConstant.MaxLoanAmount) {
            $scope.exceedsLoanAmountLimit = true;
            $scope.Borrower.LoanApplicationDetail.LoanAmount = null;
        }
        else if (amount < customerConstant.MinLoanAmount && amount > 0) {
            $scope.exceedsLoanAmountLimit = true;
            $scope.Borrower.LoanApplicationDetail.LoanAmount = null;
        }
        else if (amount == 0) {
            $scope.Borrower.LoanApplicationDetail.LoanAmount = null;
        }
    }

    $scope.defaultFieldForTheMoneyPlatform = false;
    $scope.checkLoanAmounForTheMoneyPlatform = function () {
        var amount = $scope.Borrower.LoanApplicationDetail.LoanAmount;
        $scope.defaultFieldForTheMoneyPlatform = false;

        //New Logic
        if (amount != undefined && amount != null && amount > 0) {
            $scope.defaultFieldForTheMoneyPlatform = true;
        }
    }


    $scope.closeSuggestionDiv = function () {
        $scope.IsDisplayLoanTermsSuggestionMsg = false;
    }


    $scope.SaveLoanData = function (e) {
        checkLoanAmountGratorthenZero($scope);
        e.preventDefault();

        //THIS FUNCTION IS USED TO SCROLL INTO APPLICATION ERROR CONTROLL VIEW AFTER SUBMIT THE FIELD.
        scrollIntoAppView();

        //CUSTOM VALIDATION FOR TIME IN CURRENT EMPLOYMENT FIELDS
        validateTimeInCurrentEmploymentFields($scope);

        //YOUR GROSS ANNUAL INCOME SHOULD NOT BE LESS THAN (NETMONTHLYINCOME * 12)
        $scope.validateGrossAnnualIncom(true);

        if ($scope.LoanForm.$invalid) {
            angular.forEach($scope.LoanForm.$error, function (field) {
                angular.forEach(field, function (errorField) {
                    errorField.$setTouched();
                });
            });
            return false;
        }

        if (!validateDDL($scope.Borrower.LoanApplicationDetail.LoanType)) {
            $scope.IsLoanTypeRequired = true;
            return false;
        }

        //NEW ONE - SET ADDRESS COMPONENTS - WILL REMOVE THIS CODE WHEN START VALIDATION ADDRESS AT LEAST 3 YEARS.
        $scope.Address.StayDurationInYears = $scope.AddressYear;
        $scope.Address.StayDurationInMonths = $scope.AddressMonth;
        $scope.Address.PostCode = $scope.PostalCode;
        $scope.Address.IsLatestStatus = true;

        //IF NO ADDRESS FOUND BY EQUIFAX, INPUT MANUALY ADDRESS AND CREATE FULL ADDRESS
        if (!$scope.EquiFaxAddressNotFound) {
            $scope.Address.FullAddress = $scope.Address.HouseNumber + " " + $scope.Address.Street1 + ", " + $scope.Address.PostTown + ", " + $scope.Address.District + ", " + $scope.Address.PostCode;

            //USED FOR DUMB ADDRESS IN DB, IF NOT FOUND IN EQUIFAX SEARCH
            $scope.Borrower.IsAddressFoundInEquifaxSearch = false;
            $scope.AddressList.push($scope.Address);
            $scope.Borrower.AddressList = angular.copy($scope.AddressList);
        }

        $scope.BorrowerAddresses.push($scope.Address);
        $scope.Borrower.ResidentAddress = angular.copy($scope.BorrowerAddresses);

        //VALIDATE LAST THREE YEAR ADDRESS INFO
        if ($scope.EquiFaxAddressNotFound) {
            if (!ValidateBorrowerAddress()) {
                $scope.AddressFound = true;
                return;
            }
        }

        //VALIDATE RESIDENTIAL STATUS
        if (!validateDDL($scope.Borrower.LoanApplicationDetail.ResidentialStatusID)) {
            $scope.IsResidentialStatusRequired = true;
            return false;
        }

        //VALIDATE MARITAL STATUS
        if (!validateDDL($scope.Borrower.LoanApplicationDetail.MaritalStatusID)) {
            $scope.IsMaritalStatusRequired = true;
            return false;
        }

        //NEXT PAY DATE VALIDATION
        if (!valiNextPayDate()) {
            $scope.IsNextPayDateRequired = true;
            focusOnDTP();
            return false;
        }

        if ($scope.IsInValidGrossAnnualIncome == true) {
            return false;
        }

        //VALIDATE EMPLOYMENT TYPE
        if (!validateDDL($scope.Borrower.EmployerDetail.EmploymentTypeID)) {
            $scope.IsEmploymentTypeRequired = true;
            return false;
        }

        //VALIDATE OCCUPATION
        if (!validateDDL($scope.Borrower.EmployerDetail.OccupationTypeID)) {
            $scope.IsOccupationTypeRequired = true;
            return false;
        }

        if ($scope.IsMonthlyRentValueShouldBeGreaterThanZero == false) {
            return false;
        }

        //SET BORROWER AGE IN LOAN APPLICATION
        //SET CUSTOMER DOB
        setCustomerDOB($scope);

        $scope.EmailAddress = $scope.Borrower.EmailAddress;
        $scope.PhoneNumber = $scope.Borrower.PhoneNumber;
        $scope.Borrower.EmployerDetail.EmploymentLength = $scope.EmploymentYear;
        $scope.Borrower.LoanApplicationDetail.LoanApplicationID = $scope.editLoanApplicationID;

        //FOR CUSTOMER TITLE - SET MALE - MR, FEMALE - MS, OTHER - MX
        getCustomerTitle($scope);

        //THESE FIELDS ARE FIXED NOW BUT PREVIOUSLY IT WAS USER INPUTS
        $scope.Borrower.LoanApplicationDetail.OtherMonthlyIncome = 0;  //Default value
        $scope.Borrower.LoanApplicationDetail.OtherMonthlyExpense = 0; //Default value
        $scope.Borrower.EmployerDetail.EmploymentLengthInYears = 1;    //Default value
        $scope.Borrower.EmployerDetail.EmploymentLengthInMonths = 0;   //Default value
        $scope.Borrower.LoanApplicationDetail.Term1Accepted = true; //Default value
        $scope.Borrower.LoanApplicationDetail.Term2Accepted = true; //Default value

        //set authenticatoin token 
        if (typeof (Storage) !== "undefined") {
            Role = localStorage.getItem("Key4");
            APITokenID = localStorage.getItem("Key2");
            IPAddress = localStorage.getItem("Key3");
        }

        $scope.Borrower.Role = Role;
        $scope.Borrower.APITokenID = APITokenID;
        $scope.Borrower.ReturnValue = IPAddress;

        $scope.IsSubmitLoanApp = true;
        var data = JSON.stringify($scope.Borrower);

        ShowLoanAppDialog();
        ControllerService.Post(
            "/Customer/SaveLoanApplication", data, function (status, responseData) {
                HideLoanAppDialog();
                if (status && responseData.Status == false) {
                    $scope.IsSubmitLoanApp = false;
                    var msg = responseData.Message != null ? responseData.Message : customerConstant.SomsomethingWentWrong;
                    ShowError("Loan Application", msg);
                }
                else if (responseData.Status) {
                    HideLoanAppDialog();
                    $scope.LoanApplicationId = $scope.Borrower.LoanApplicationDetail.LoanApplicationID = responseData.ReturnValue;

                    //SET AUTHENTICATOIN TOKEN & REDIRECT ON OFFERS
                    redirectToOffers(generateNumber(10) + responseData.ReturnValue + JSSecretKey);
                    //END METHOD
                }
            });
    }
    
    $scope.matchDataMsg = function (str, nb) {
        var array = [];
        if (str != undefined && str.length > 0)
            array = str.split('\n');
        return array[nb];
    }

    $scope.IsResubmitLoanTypeRequired = false;
    $scope.validateResubmitLoanType = function () {
        $scope.IsResubmitLoanTypeRequired = false;
    }

    $scope.IsResubmited = function () {
        if (!$scope.isResubmit) {
            return false;
        }
        return true;
    }

    $scope.filterValue = function ($event) {
        if (isNaN(String.fromCharCode($event.keyCode))) {
            $event.preventDefault();
        }
    };

    $scope.noLoanMatchedfalg = true;
    $scope.clearLoanResultFilter = function () {
        $scope.noLoanMatchedfalg = true;
        $scope.noLoanMatchedFound = false;
        $scope.LendersSearchKeys.Id = 0;
        $scope.MatchedLenderList = $scope.MatchedLenderResultList;
    }

    $scope.changeFilterLoanResult = function (key) {
        if (key.Id == 1 || key.Id == 3 || key.Id == 4) {
            //Call For Get LOWEST Total Payable. key.Id == 1 meanse this is a lowest Total Payable filter
            if (key.Id == 1) {
                //getLowestTotalPayableFilter();
                $scope.MatchedLenderList = $scope.MatchedLenderResultList;

                //Show Progress bar
                ShowFilterLoanAppDialog();
                //2 seconds delay
                $timeout(function () { HideFilterLoanAppDialog(); }, 1000);
            }

            //Call For Get LOWEST APR. key.Id == 3 meanse this is a lowest APR filter
            if (key.Id == 3) {
                //getLowestAPR();
                $scope.MatchedLenderList = $scope.MatchedLenderResultList;

                //Show Progress bar
                ShowFilterLoanAppDialog();
                //2 seconds delay
                $timeout(function () { HideFilterLoanAppDialog(); }, 1000);
            }

            //Call For Get Monthly Installment Amount - EMIAmount. key.Id == 4 meanse this is a monthly EMI Amount filter
            if (key.Id == 4) {
                //getLowestMonthlyInstallmentFilter();
                $scope.MatchedLenderList = $scope.MatchedLenderResultList;

                //Show Progress bar
                ShowFilterLoanAppDialog();
                //2 seconds delay
                $timeout(function () { HideFilterLoanAppDialog(); }, 1000);
            }

            //Handle the flags.
            $scope.noLoanMatchedfalg = true;
            $scope.noLoanMatchedFound = false;
        } else {
            $scope.filterLoanResult(key.Id);
        }
    }

    $scope.noLoanMatchedFound = false;
    $scope.MatchedLenderResultList = [];

    $scope.filterLoanResult = function (ids) {
        var request = {};
        if (typeof (Storage) !== "undefined") {
            request.Role = localStorage.getItem("Key4");
            request.APITokenID = localStorage.getItem("Key2");
            request.InternalIP = localStorage.getItem("Key3");
        }

        var loanAppId = $scope.editLoanApplicationID + "-" + ids;

        ShowFilterLoanAppDialog();
        ControllerService.Post(
            "/Customer/FilterLoanResult", { obj: request, LoanAppId: loanAppId }, function (status, responseData) {

                
                if (status && responseData.Status == false) {
                    ShowError("Loan Application", responseData.Message)
                }
                else if (responseData.Status) {
                    $scope.isApplicationSaved = true;
                    $scope.isApplicationProcessed = true;

                    if (responseData.MatchedLenderList.length == 0) {
                        $scope.noLoanMatchedFound = true; //display the no result found msg.
                        $scope.noLoanMatchedfalg = false; //disable loan filter result grid flag.
                    }
                    else {
                        $scope.MatchedLenderList = responseData.MatchedLenderList;
                        $scope.noLoanMatchedFound = false; //display the no result found msg.
                        $scope.noLoanMatchedfalg = true; //enable loan filter result grid flag.
                    }

                    //Lable - Loan Application Result
                    $scope.LoanApplicationTitle = customerConstant.TitleLoanAppResult;
                }

                //2 seconds delay
                $timeout(function () { HideFilterLoanAppDialog(); }, 1000);
            });
    }

    //DOB
    svm.Day = "";
    svm.Month = "";
    svm.Year = "";
    svm.validDay = true;
    svm.Message = "";
    svm.MessageInvalidAge = "";

    svm.Day1 = "";
    svm.Month1 = "";
    svm.Year1 = "";
    svm.validDay1 = true;
    svm.Message1 = "";
    svm.MessageInvalidAge1 = "";

    $scope.CheckValidNextPayDate = function () {
        //validate the Next pay date
        if ($scope.Day1 == "" || $scope.Month1 == "" || $scope.Year1 == "") {
            $scope.validDay1 = true;
            return;
        }

        var nextPayDate1 = $scope.Day1 + "/" + $scope.Month1 + "/" + $scope.Year1;
        var nextPayDate = $scope.Month1 + "/" + $scope.Day1 + "/" + $scope.Year1;

        $scope.Borrower.LoanApplicationDetail.NextPayDate = nextPayDate1;

        var todayDate = new Date();
        var date = new Date(Date.parse(nextPayDate));

        var dateOne = new Date(todayDate.getFullYear(), (todayDate.getMonth() + 1), todayDate.getDate()); //Year, Month, Date
        var dateTwo = new Date(date.getFullYear(), (date.getMonth() + 1), date.getDate()); //Year, Month, Date

        if (dateOne > dateTwo) {
            //console.log("Invalid date");
            $scope.validDay1 = false;
            $scope.MessageInvalidAge1 = customerConstant.InvalidPayDate;
            //Invalid date
        } else {
            //console.log("valid date");
            $scope.validDay1 = true;
            $scope.MessageInvalidAge1 = "";
            //valid date
        }
    }

    $scope.CheckValidDay = function () {
        
        if ($scope.Day == "" || $scope.Month == "" || $scope.Year == "") {
            $scope.validDay = true;
            return;
        }
        
        var DOB = $scope.Day + "/" + $scope.Month + "/" + $scope.Year;
        $scope.Borrower.DOB = DOB;
       
        if (!isValidDate(DOB)) {
            $scope.validDay = false;
            $scope.MessageInvalidAge = customerConstant.InvalidDate;
            return false;
        }
        else {
            var startdate = ConvertToJSDate(DOB);
            var enddate = GetCurrentJSDate();
            var diffDays = DateDifference(startdate, enddate);
            diffDays = parseInt(diffDays);
            var year = parseInt(diffDays / 365);

            if (year < 18) {
                $scope.validDay = false;
                $scope.MessageInvalidAge = customerConstant.AgeShould18Year;
                return false;
            }
            $scope.validDay = true;            
            return true;
        }        
    }

    //Enable form sections
    svm.enableResidentialSecFields = false;
    svm.enableResidentialSection = function () {
        let cmr = svm.Borrower;
        let lp = svm.Borrower.LoanApplicationDetail;       
        if (!isNullOrEmpty(cmr.EmailAddress) && !isNullOrEmpty(cmr.PhoneNumber)
            && !isNullOrEmpty(cmr.FirstName) && !isNullOrEmpty(cmr.LastName)
            /*&& !isNullOrEmpty(cmr.DOB)*/ && !isNullOrEmpty(getDDLSelectedText(svm.MaritalStutusList, lp.MaritalStatusID))){
            svm.enableResidentialSecFields = true;
        }
    }

    svm.enableFinancialInformationSecFields = false;
    svm.enableFinancialInformationSection = function () {
        let lp = svm.Borrower.LoanApplicationDetail;
        if (!isNullOrEmpty(svm.PostalCode) && !isNullOrEmpty(svm.AddressYear)
            && !isNullOrEmpty(svm.AddressMonth) && !isNullOrEmpty(getDDLSelectedText(svm.HousingType, lp.ResidentialStatusID))) {
            svm.enableFinancialInformationSecFields = true;
        }
    }
    //END -Enable form sections

    }]);

app.directive('allowOnlyNumbers', function () {
    return {
        restrict: 'A',
        link: function (scope, elm, attrs, ctrl) {
            elm.on('keydown', function (event) {
                if (event.which == 64 || event.which == 16) {
                    // to allow numbers  
                    return false;
                } else if (event.which >= 48 && event.which <= 57) {
                    // to allow numbers  
                    return true;
                } else if (event.which >= 96 && event.which <= 105) {
                    // to allow numpad number  
                    return true;
                } else if ([8, 13, 27, 37, 38, 39, 40].indexOf(event.which) > -1) {
                    // to allow backspace, enter, escape, arrows  
                    return true;
                } else {
                    event.preventDefault();
                    // to stop others  
                    return false;
                }
            });
        }
    }
}); 

app.directive('restrictSpecialCharactersDirective', function () {
    function link(scope, elem, attrs, ngModel) {
        ngModel.$parsers.push(function (viewValue) {
            var reg = /^[0-9]*$/;
            if (viewValue.match(reg)) {
                return viewValue;
            }
            var transformedValue = ngModel.$modelValue;
            ngModel.$setViewValue(transformedValue);
            ngModel.$render();
            return transformedValue;
        });
    }

    return {
        restrict: 'A',
        require: 'ngModel',
        link: link
    };
});

//FOR REFRENCE SITE LOGO URL REPLACEMENT
function setlendingLogoURL(refWebSiteName, customerConstant, $rootScope) {
    if (refWebSiteName == customerConstant.UK786loans) {
        $rootScope.lendingLogoURL = $rootScope.baseURL + customerConstant.UK786loansLogo;
    }
    else if (refWebSiteName == customerConstant.LoanBroker) {
        $rootScope.lendingLogoURL = $rootScope.baseURL + customerConstant.LoanBrokerLogo;
    }
    else if (refWebSiteName == customerConstant.OysterLoan) {
        $rootScope.lendingLogoURL = $rootScope.baseURL + customerConstant.OysterLoanLogo;
    }
    else if (refWebSiteName == customerConstant.LoanPrincess) {
        $rootScope.lendingLogoURL = $rootScope.baseURL + customerConstant.LoanPrincessLogo;
    }
}

//SET CUSTOMER DOB
function setCustomerDOB($scope) {
    var dob = $scope.Day + "/" + $scope.Month + "/" + $scope.Year;
    if ($scope.Borrower.DOB == null) {
        if (isValidDate(dob))
            $scope.Borrower.LoanApplicationDetail.DateOfBirth = dob;
    }
    else {
        $scope.Borrower.LoanApplicationDetail.DateOfBirth = $scope.Borrower.DOB;
    }
}

function checkLoanAmountGratorthenZero($scope) {
    if ($scope.Borrower.LoanApplicationDetail.LoanAmount == 0) {
        $scope.Borrower.LoanApplicationDetail.LoanAmount = null;
    }
}

function validateTimeInCurrentEmploymentFields($scope) {
    if ($scope.CurrentEmploymentIsRequired == undefined || $scope.CurrentEmploymentIsRequired == true) {
        $('#employmentLengthInYears, #employmentLengthInMonths').css("border", "1px solid red");
    }
}

function getCustomerTitle($scope) {
    if ($scope.Borrower.Gender == "1") {
        $scope.Borrower.Title = "Mr";
    }
    else if ($scope.Borrower.Gender == "2") {
        $scope.Borrower.Title = "Ms";
    }
    else {
        $scope.Borrower.Title = "Mx";
    }
}