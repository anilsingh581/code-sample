﻿//START: USED TO BIND THE DATE OF BIRTH - DAY, MONTH, AND YEAR SELECTION DDL.
    bindDateOfBirth();
//END DOB

//START: REFERRER SITE URLS
    setUrlParams();
//END

$(function () {
    //THIS METHOD IS USED FOR DATETIMEPICKER FOR NEXT PAY DATE
    nextPayDateCalendar();

    //THIS METHOD IS USED FOR DATETIMEPICKER FOR 2ND NEXT PAY DATE
    secondNextPayDateCalendar();

    //SCROLL NAV BAR
    scrollNavbar();

    //VALIDATE PAY DATES
    validatePaysDate();
});

//THIS LINE OF CODE IS USED TO GET REFERRER LOAN AMOUNT AND LOAN TERMS, AND SO ON TO SET IN THE LOAN APPLICATION URLS.
function setUrlParams() {
    var loanamount, loanterm, refSiteName, refPageName, ref, reqID, affID, offerID, ajentID;
    loanamount = getURLSearchParams("amount"); 
    loanterm = getURLSearchParams("term"); 
    refSiteName = getURLSearchParams("utm_website");
    refPageName = getURLSearchParams("utm_webpage");
    ref = document.referrer;
    reqID = getURLSearchParams("ReqID");
    affID = getURLSearchParams("affid");
    offerID = getURLSearchParams("offerId");
    agentID = getURLSearchParams("agent");

    loanamount = (loanamount != undefined && loanamount != null && loanamount != 0) ? parseInt(loanamount) : '';
    loanterm = (loanterm != undefined && loanterm != null && loanterm != 0) ? parseInt(loanterm) : '';
    refSiteName = (refSiteName != undefined && refSiteName != null && refSiteName != '') ? refSiteName : ((ref != undefined && ref.length > 0) ? ref.split('/')[2] : "loantube.com");
    refPageName = (refPageName != undefined && refPageName != null && refPageName != '') ? refPageName : ((ref != undefined && ref.length > 0) ? ref : "app.loantube.com/Customer/LoanApplication");

    reqID = (reqID != undefined && reqID != null) ? reqID : '';
    affID = (affID != undefined && affID != null) ? affID : '';
    offerID = (offerID != undefined && offerID != null) ? offerID : '';
    agentID = (agentID != undefined && agentID != null) ? agentID : false;

    if (typeof (Storage) !== "undefined") {
        localStorage.setItem("LoanAmount", loanamount);
        localStorage.setItem("LoanTerm", loanterm);
        localStorage.setItem("RefWebSiteName", refSiteName);

        if (!agentID) {
            localStorage.setItem("RefWebPageName", refPageName);
        } else {
            localStorage.setItem("RefWebPageName", "agent: " + agentID);
            //AgentFilled email flow - its bad idea to do this but...
            localStorage.setItem("agentByEmail", true);
        }

        localStorage.setItem("ReqID", reqID);
        localStorage.setItem("affid", affID);
        localStorage.setItem("offerId", offerID);
        localStorage.setItem("agentID", "agent: " + agentID);  
    }
}

//THIS METHOD IS USED FOR DATETIMEPICKER FOR NEXT PAY DATE.
var setStartDate = new Date();
setStartDate.setDate(setStartDate.getDate() + 1);
var nextPayDateCalendar = function () {   
    $('#nextPayDate').datepicker({
        format: 'dd/mm/yyyy',
        startDate: setStartDate,
        //todayHighlight: true,
        toggleActive: true,
        clearBtn: true,
        autoclose: true
    });
}

//THIS METHOD IS USED FOR DATETIMEPICKER FOR 2ND NEXT PAY DATE.
var secondNextPayDateCalendar = function () {
    var today = new Date();
    var start_Date = new Date(today.setDate(today.getDate() + 1));

    $('#SecondNextPayDateDP').datepicker({
        format: 'dd/mm/yyyy',
        startDate: start_Date,
        //todayHighlight: true,
        toggleActive: true,
        clearBtn: true,
        autoclose: true
    });
}

//VALIDATE PAY DATES
var validatePaysDate = function () {
    $("#nextPayDate").datepicker({
        format: 'dd/mm/yyyy',
        startDate: setStartDate,
        //todayHighlight: true,
        toggleActive: true,
        clearBtn: true,
        autoclose: true
    }).on('changeDate', function (selected) {        
        var secNextPD = $('#SecondNextPayDateDP');
        secNextPD.val("");//CLEAR 2ND NEXT PAY DATE, IF SELECTED BEFORE NEXT PAY DATE.

        var selectedDate = new Date(selected.date);
        var date = addDays(selectedDate, 5); //Added 5 days in selected date.
        var minDate = new Date(date.valueOf());
        secNextPD.datepicker('setStartDate', minDate);
    });
}

//SCROLL NAV BAR
var scrollNavbar = function () {
    $(window).scroll(function() {
        if ($(document).scrollTop() > 1) {
            $(".navbar-default").addClass('navTp');
        }
        else {
            $(".navbar-default").removeClass('navTp');
        }
    });
}

//BIND THE DATE OF BIRTH - DAY, MONTH, AND YEAR SELECTION DDL.
function bindDateOfBirth() {
    var select = $("#Day");
    select.append($('<option></option>').val("").html("Day..."));
    for (i = 1; i <= 31; i++) {
        if (i <= 9) {
            i = '0' + i;
        }
        select.append($('<option></option>').val(i).html(i));
    }
    var d = new Date();
    var currentYear = d.getFullYear();
    var startYear = currentYear - 100;
    currentYear = currentYear - 18;
    var select = $("#Year");
    select.append($('<option></option>').val("").html("Year..."));
    var yearArray = [];
    for (i = startYear; i <= currentYear; i++) {
        yearArray.push(i);
    }
    yearArray = yearArray.reverse();
    for (j = 0; j < yearArray.length; j++) {
        select.append($('<option></option>').val(yearArray[j]).html(yearArray[j]));
    }
}