﻿using Logger;
using Microsoft.AspNetCore.Mvc;
using Models;
using Newtonsoft.Json;
using System.IO;
using WebAPIHelper;

namespace WebApp.Controllers
{
    /// <summary>
    /// USED FOR LENDER - BAMBOO
    /// BAMBOO USING AS 3rd PARTY API AT BAMBOO END, TO UPDATE LOAN STATUS
    /// </summary>
    public class LenderWebhookController : ControllerBase
    {
        ICommonHelper commonHelper = null;
        public LenderWebhookController(ICommonHelper _commonHelper)
        {
             commonHelper= _commonHelper;
        }
        /// <summary>
        /// BAMBOO WEBHOOK STATUS UPDATE
        /// </summary>
        [HttpPost]
        public ActionResult<ResponseModel> BambooStatusUpdate()
        {
            ResponseModel model = new ResponseModel();
            try
            {
                Logger.ErrorLog.LogMessage("Request received for BambooStatusUpdate");
               
                string result = string.Empty;
                using (var reader = new StreamReader(Request.Body))
                {
                    result = reader.ReadToEnd();
                }

                ErrorLog.LogMessage(result);                           
                var obj = JsonConvert.DeserializeObject<BambooWebHookRequestModel>(result);                               

                model = commonHelper.LenderWebhook(obj);
                if (model.Message == "UNAUTHORIZED")
                    RedirectToAction("RemoveAuthetication", "Account");


            }
            catch (System.Exception ex)
            {
                ErrorLog.LogException(ex);

            }
            return Ok(model);



        }
               
    }
}
