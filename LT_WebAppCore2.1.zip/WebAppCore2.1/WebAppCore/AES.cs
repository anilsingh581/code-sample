﻿using Microsoft.Extensions.Configuration;
using Models;
using System;
using System.Configuration;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Security
{
    public  class AES:IAES
    {
        #region ENCRYPT AND DECRYPT DATA BY USING THE AES ALGORITHM - Advanced Encryption Standard (AES)

        /// <summary>
        /// SAME KEY AS IN CUSTOM.JS FILE
        /// </summary>
        private readonly string JSSecretKey = "fxhp5tygx9";
        IConfiguration configuration = null;
        public AES(IConfiguration _configuration)
        {
            configuration = _configuration;
        }
        public string GetJSSecretKey()
        {
            return JSSecretKey;
        }

        /// <summary>
        /// ENCRYPT STRING USING AES
        /// </summary>
        public string EncryptStringAES(string cipherText)
        {
            var keybytes = Encoding.UTF8.GetBytes(configuration.GetValue<string>("secretkey"));
            var iv = Encoding.UTF8.GetBytes(configuration.GetValue<string>("secretkey"));
            var encryptred = Convert.ToBase64String(EncryptStringToBytes(cipherText, keybytes, iv));

            return string.Format(encryptred);
        }

        /// <summary>
        /// DECRYPT STRING USING AES
        /// </summary>
        public  string DecryptStringAES(string cipherText)
        {
            var keybytes = Encoding.UTF8.GetBytes(configuration.GetValue<string>("secretkey"));
            var iv = Encoding.UTF8.GetBytes(configuration.GetValue<string>("secretkey"));

            var encrypted = Convert.FromBase64String(cipherText);
            var decriptedFromJavascript = DecryptStringFromBytes(encrypted, keybytes, iv);

            return string.Format(decriptedFromJavascript);
        }

        /// <summary>
        /// DECRYPT STRING FROM BYTES
        /// </summary>
        private  string DecryptStringFromBytes(byte[] cipherText, byte[] key, byte[] iv)
        {
            // CHECK ARGUMENTS.
            if (cipherText == null || cipherText.Length <= 0)
            {
                throw new ArgumentNullException("cipherText");
            }

            if (key == null || key.Length <= 0)
            {
                throw new ArgumentNullException("key");
            }

            if (iv == null || iv.Length <= 0)
            {
                throw new ArgumentNullException("key");
            }

            // DECLARE THE STRING USED TO HOLD
            // THE DECRYPTED TEXT.
            string plaintext = null;

            // CREATE AN RIJNDAELMANAGED OBJECT
            // WITH THE SPECIFIED KEY AND IV.
            using (var rijAlg = new RijndaelManaged())
            {
                //Settings
                rijAlg.Mode = CipherMode.CBC;
                rijAlg.Padding = PaddingMode.PKCS7;
                rijAlg.FeedbackSize = 128;

                rijAlg.Key = key;
                rijAlg.IV = iv;

                // CREATE A DECRYTOR TO PERFORM THE STREAM TRANSFORM.
                var decryptor = rijAlg.CreateDecryptor(rijAlg.Key, rijAlg.IV);
                try
                {
                    // CREATE THE STREAMS USED FOR DECRYPTION.
                    using (var msDecrypt = new MemoryStream(cipherText))
                    {
                        using (var csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                        {
                            using (var srDecrypt = new StreamReader(csDecrypt))
                            {
                                // READ THE DECRYPTED BYTES FROM THE DECRYPTING STREAM
                                // AND PLACE THEM IN A STRING.
                                plaintext = srDecrypt.ReadToEnd();
                            }
                        }
                    }
                }
                catch
                {
                    plaintext = "keyError";
                }
            }

            return plaintext;
        }

        /// <summary>
        /// ENCRYPT STRING TO BYTES
        /// </summary>
        private  byte[] EncryptStringToBytes(string plainText, byte[] key, byte[] iv)
        {
            // CHECK ARGUMENTS.
            if (plainText == null || plainText.Length <= 0)
            {
                throw new ArgumentNullException("plainText");
            }
            if (key == null || key.Length <= 0)
            {
                throw new ArgumentNullException("key");
            }
            if (iv == null || iv.Length <= 0)
            {
                throw new ArgumentNullException("key");
            }
            byte[] encrypted;
            // CREATE A RIJNDAELMANAGED OBJECT
            // WITH THE SPECIFIED KEY AND IV.
            using (var rijAlg = new RijndaelManaged())
            {
                rijAlg.Mode = CipherMode.CBC;
                rijAlg.Padding = PaddingMode.PKCS7;
                rijAlg.FeedbackSize = 128;

                rijAlg.Key = key;
                rijAlg.IV = iv;

                // CREATE A DECRYTOR TO PERFORM THE STREAM TRANSFORM.
                var encryptor = rijAlg.CreateEncryptor(rijAlg.Key, rijAlg.IV);

                // CREATE THE STREAMS USED FOR ENCRYPTION.
                using (var msEncrypt = new MemoryStream())
                {
                    using (var csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (var swEncrypt = new StreamWriter(csEncrypt))
                        {
                            //WRITE ALL DATA TO THE STREAM.
                            swEncrypt.Write(plainText);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }

            // RETURN THE ENCRYPTED BYTES FROM THE MEMORY STREAM.
            return encrypted;
        }
        #endregion
    }
}
