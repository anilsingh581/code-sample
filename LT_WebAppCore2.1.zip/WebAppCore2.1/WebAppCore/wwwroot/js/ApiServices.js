﻿angular.module("ui.Services", []).
service("ControllerService", ["$http", function ($http) {
    var LocalUrl = "";
    this.Post = function (url, data, callback) {
        $http({
            url: LocalUrl + url,            
            method: "POST",
            data: data,           
            headers: {
                "Content-Type": "application/json"
            }
        }).
        then(function mySuccess(response) {
            callback(true, response.data);
        }, function myError(response) {
            callback(false, response.data);
        });
    };

    this.Get = function (url, data, callback) {
        $http({
            url: LocalUrl + url,
            params: data,
            method: "GET",
            headers: {}
        }).then(function mySuccess(response) {
            callback(true, response.data);
        }, function myError(response) {
            callback(false, response.data);
        });

    };

    //CORS is Cross Origin Resource Sharing
    // In your case, JSONP should work fine because it only uses the GET method.
    this.GetJSONP = function (url, data, callback) {
        $http({
            url: LocalUrl + url,
            method: "JSONP"
        }).
            then(function mySuccess(response) {
                callback(true, response.data);
            }, function myError(response) {
                callback(false, response.data);
            });
    };
}]);