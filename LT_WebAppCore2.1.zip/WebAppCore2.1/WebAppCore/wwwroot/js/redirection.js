﻿var app = angular.module("myApp", ["ui.Services"]);

app.controller('redirectCtrl', ["$scope", "ControllerService", "redirectionResultConstant", function ($scope, ControllerService, redirectionResultConstant) {
    var svm = $scope;
    svm.lenderDeepLinkURL = "/images/logo/deeplink/loader.gif";//default loding...
    svm.defaultLogo = true;
    svm.lenderRedirectURL = null;

    svm.redirectToLender = function (offerId) {
       // alert(offerId);
        var data = { offerId: offerId }

        ControllerService.Post("/Customer/LoanAggrement", data, function (status, responseData) {
            if (responseData.Status == false) {
                var msg = responseData.Message != null ? responseData.Message : redirectionResultConstant.SomsomethingWentWrong;
                ShowError("Loan Application", msg);
            }
            else if (responseData.Status == true) {
                var redirectURL = responseData.CustomerRedirectUrl;

                //See before Redirect to lender URL                
                svm.lenderDeepLinkURL = responseData.LogoUrl;
                svm.defaultLogo = false;

                if (!isValidURL(redirectURL))
                    redirectURL = "http://" + redirectURL;

                svm.lenderRedirectURL = redirectURL;

                setTimeout(function () {
                    if (redirectURL != undefined && redirectURL != null && redirectURL != "") {
                        ControllerService.Post("/Customer/LoanAggrementLogs", { loanAppID: offerId, loanRedirectingURL: redirectURL }, function (status, responseData) { });

                        //redirect to lender site id all are good.                        
                        document.location.href = redirectURL;
                        //checkURLIsExist(redirectURL);
                    }
                }, 2000);               
            }

        });
    }

}]);
app.constant("redirectionResultConstant", (function () {
    return {
        SomsomethingWentWrong: "Something went wrong while processing your request. Please try again or contact us for assistance.",
    }
})());

var checkURLIsExist = function (url) {
    console.log(url);

    fetch(url, { method: 'HEAD', mode: 'no-cors' })
        .then(res => {
            console.log(res);
            if (res.ok) {
                console.log('URL exists.');
            } else {
                console.log('URL does not exist.');
            }
        })
        .catch(err => console.log('Error:', err));
}
var ShowError = function (header, error) {
    $("#showErrorModal .modal-title").html(header)
    $("#showErrorModal .modal-msg").html(error)
    $("#showErrorModal").modal();
}