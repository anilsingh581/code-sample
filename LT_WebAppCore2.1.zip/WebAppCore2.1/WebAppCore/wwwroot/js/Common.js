﻿var app = app || angular.module("myApp", ["ui.Services"]);

app.controller("cCommon", ["$scope", "$rootScope", "ControllerService", "subdomain", function ($scope, $rootScope, ControllerService, subdomain) {
    var svm = $scope;
    var rsvm = $rootScope;

    svm.formdata = {};
    svm.confirmationMessage = "";

    rsvm.baseURL = subdomain;//SET THE BASE URL FOR GLOBAL LEVEL.        
    rsvm.lendingLogoURL = "/images/customer/logo.png";  

    //CONVERT STRING TO DATE FORMAT AND APPLY THE FORMATT
    rsvm.formatDate = function (date) {
        var dateOut = new Date(date);
        return dateOut;
    }
}]);

var JSSecretKey = 'fxhp5tygx9';

//CHECK MOBILE DEVICES
var isMobile = {
    Android: function () {
        return navigator.userAgent.match(/Android/i);
    },
    BlackBerry: function () {
        return navigator.userAgent.match(/BlackBerry/i);
    },
    iOS: function () {
        return navigator.userAgent.match(/iPhone|iPad|iPod/i);
    },
    Opera: function () {
        return navigator.userAgent.match(/Opera Mini/i);
    },
    Windows: function () {
        return navigator.userAgent.match(/IEMobile/i);
    },
    any: function () {
        return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
    }
}

var JSONParse = function (obj) {
    return JSON.parse(obj);
}

//USE FOR SCROLL HEADER ON TOP FOR LOAN RESULT AND VIEWLOAN EMAIL FLOW PAGE
$(window).scroll(function () {
    var header = $("#myHeader");
    var scroll = $(window).scrollTop();
    if (scroll > 107) {
        header.addClass("stickyTableHeader");
    } else {
        header.removeClass("stickyTableHeader");
    }
});

//open new tab after click on.
var openInNewTabWinBrowser = function (url) {
    var wind = window.open('', '_blank');
    wind.location = url;
}

//#region : Popups Dialogs
function ShowDialog() {
    $("#waitdiv").show();
}

function HideDialog() {
    $("#waitdiv").hide();
}

function ShowProcessLoan() {
    $("#ProcessDiv").show();
}

function HideProcessLoan() {
    $("#ProcessDiv").hide();
}

function ShowLoanAppDialog() {
    $("#waitLoanAppdiv").show();
}

function HideLoanAppDialog() {
    $("#waitLoanAppdiv").hide();
}

function ShowFilterLoanAppDialog() {
    $("#waitFilterLoanAppdiv").show();
}

function HideFilterLoanAppDialog() {
    $("#waitFilterLoanAppdiv").hide();
}

function setHeadingforDefaultValues() {
    $('input, textarea').each(function () {
        var valls = $(this).val();
        if (valls != "") {
            $(this).addClass("hascontent");
        } else {
            $(this).removeClass("hascontent");
        }
    });
}
//#endregion

$(function () {
    $(".numeric").bind("keypress", function (e) {
        var specialKeys = new Array();
        specialKeys.push(8); //Backspace
        specialKeys.push(9); //Tab
        specialKeys.push(35); //end
        specialKeys.push(36); //home
        specialKeys.push(37); //left arrow
        specialKeys.push(39); //right arrow
        var keyCode = e.which ? e.which : e.keyCode
        var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
        //$(".error").css("display", ret ? "none" : "inline");
        return ret;
    });

    $(".numeric").bind("paste", function (e) {
        return false;
    });

    $(".numeric").bind("drop", function (e) {
        return false;
    });

    $(".decimal").bind("keypress", function (e) {
        var DecimalInputspecialKeys = new Array();
        DecimalInputspecialKeys.push(8); //Backspace
        DecimalInputspecialKeys.push(9); //Tab
        DecimalInputspecialKeys.push(35); //end
        DecimalInputspecialKeys.push(36); //home
        DecimalInputspecialKeys.push(37); //left arrow
        DecimalInputspecialKeys.push(39); //right arrow
        DecimalInputspecialKeys.push(46); //decimal

        var keyCode = e.which ? e.which : e.keyCode
        var ret = ((keyCode >= 48 && keyCode <= 57) || DecimalInputspecialKeys.indexOf(keyCode) != -1);
        return ret;
    });

    $(".decimal").bind("paste", function (e) {
        return false;
    });

    $(".decimal").bind("drop", function (e) {
        return false;
    });
});

$(window).load(function () {
    setHeadingforDefaultValues();
})

function isValidDate(s) {
    var bits = s.split('/');
    var d = new Date(bits[2], bits[1] - 1, bits[0]);
    return d && (d.getMonth() + 1) == bits[1];
}

function ConvertToJSDate(dt) {
    var date = dt.split('/');
    date = date[1] + '/' + date[0] + '/' + date[2];
    return new Date(date);
}

function DateDifference(startdate, enddate) {
    var timeDiff = Math.abs(enddate.getTime() - startdate.getTime());
    var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
    return diffDays;
}

function GetCurrentDate() {
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!

    var yyyy = today.getFullYear();
    if (dd < 10) {
        dd = '0' + dd;
    }
    if (mm < 10) {
        mm = '0' + mm;
    }
    var today = dd + '/' + mm + '/' + yyyy;
    return today;
}

function GetCurrentJSDate() {
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!

    var yyyy = today.getFullYear();
    if (dd < 10) {
        dd = '0' + dd;
    }
    if (mm < 10) {
        mm = '0' + mm;
    }
    var today = mm + '/' + dd + '/' + yyyy;
    return new Date(today);
}

//GET CLIENT IP;
function getUserIP(onNewIP) { //  onNewIp - your listener function for new IPs
    //compatibility for firefox and chrome

    var myPeerConnection = window.RTCPeerConnection || window.mozRTCPeerConnection || window.webkitRTCPeerConnection;

    var pc = new myPeerConnection({
        iceServers: []
    }),
        noop = function () { },
        localIPs = {},
        ipRegex = /([0-9]{1,3}(\.[0-9]{1,3}){3}|[a-f0-9]{1,4}(:[a-f0-9]{1,4}){7})/g,
        key;

    function iterateIP(ip) {
        if (!localIPs[ip]) onNewIP(ip);
        localIPs[ip] = true;
    }

    //create a bogus data channel
    pc.createDataChannel("");

    // create offer and set local description
    pc.createOffer(function (sdp) {
        sdp.sdp.split('\n').forEach(function (line) {
            if (line.indexOf('candidate') < 0) return;
            line.match(ipRegex).forEach(iterateIP);
        });

        pc.setLocalDescription(sdp, noop, noop);
    }, noop);

    //listen for candidate events
    pc.onicecandidate = function (ice) {
        if (!ice || !ice.candidate || !ice.candidate.candidate || !ice.candidate.candidate.match(ipRegex)) return;
        ice.candidate.candidate.match(ipRegex).forEach(iterateIP);
    };
}

//Split string
function splitString(str, seperator) {
    if (str != undefined && str != null && str != "")
        return str.split(seperator);
}

//CONFIMATION FOR USER ACTION
function AsyncConfirmYesNo(title, msg, yesFn, data) {
    var $div = $('<div id="modalConfirmYesNo" class="modal fade">' +
        '<div class="modal-dialog" >' +
        '<div class="modal-content">' +
        '<div class="modal-header">' +
        '<button type="button"' +
        'class="close" data-dismiss="modal" aria-label="Close">' +
        '<span aria-hidden="true">&times;</span>' +
        '</button>' +
        '<h4 id= "lblTitleConfirmYesNo" class="modal-title" > Confirmation</h4 > ' +
        '</div > ' +
        '<div class="modal-body" > ' +
        '<p id="lblMsgConfirmYesNo" ></p > ' +
        '</div > ' +
        '<div class="modal-footer" > ' +
        '<button id= "btnYesConfirmYesNo" type= "button" class="btn btn-success btn-lg" >Yes</button>' +
        '<button id= "btnNoConfirmYesNo" type= "button" class="btn btn-danger btn-lg" >No</button>' +
        '</div> ' +
        '</div> ' +
        '</div> ' +
        '</div>');

    $div.appendTo('body');
    var $confirm = $("#modalConfirmYesNo");
    $confirm.modal('show');
    $("#lblTitleConfirmYesNo").html(title);
    $("#lblMsgConfirmYesNo").html(msg);

    $("#btnYesConfirmYesNo").off('click').click(function () {
        yesFn(data);
        $confirm.modal("hide");
    });

    $("#btnNoConfirmYesNo").off('click').click(function () {
        //noFn();
        $confirm.modal("hide");
    });
}

function AsyncConfirmYesNoForPartnerCall(title, msg, yesFn, data) {
    var $div = $('<div id="modalConfirmYesNo" class="modal fade">' +
        '<div class="modal-dialog" >' +
        '<div class="modal-content">' +
        '<div class="modal-header">' +
        '<button type="button"' +
        'class="close" data-dismiss="modal" aria-label="Close">' +
        '<span aria-hidden="true">&times;</span>' +
        '</button>' +
        '<h3 id= "lblTitleConfirmYesNo" class="modal-title" > Confirmation</h3> ' +
        '</div > ' +
        '<div class="modal-body" > ' +
        '<p id= "lblMsgConfirmYesNo" ></p > ' +
        '<p class="lnkFriendsCapital">Click here for Friends Capital <a href="https://www.friendscapital.co.uk/terms.html" target="_blank">Terms & Conditions</a></p > ' +
        '</div > ' +
        '<div class="modal-footer" > ' +
        '<button id= "btnYesConfirmYesNo" type= "button" class="btn btn-success btn-lg" >Yes</button>' +
        '<button id= "btnNoConfirmYesNo" type= "button" class="btn btn-danger btn-lg" >No</button>' +
        '</div> ' +
        '</div> ' +
        '</div> ' +
        '</div>');

    $div.appendTo('body');
    var $confirm = $("#modalConfirmYesNo");
    $confirm.modal('show');
    $("#lblTitleConfirmYesNo").html(title);
    $("#lblMsgConfirmYesNo").html(msg);
    $("#btnYesConfirmYesNo").off('click').click(function () {
        yesFn(data);
        $confirm.modal("hide");
    });
    $("#btnNoConfirmYesNo").off('click').click(function () {
        //noFn();
        $confirm.modal("hide");
    });
}

function AsyncAcceptLoanConfirmYesNo(title, msg, yesFn, data) {
    var $div = $('<div id="modalConfirmYesNo" class="modal fade acceptLoanYesNo" style="padding-top: 50px;">' +
        '<div class="modal-dialog" >' +
        '<div class="modal-content">' +
        '<div class="modal-header">' +
        '<button type="button"' +
        'class="close" data-dismiss="modal" aria-label="Close">' +
        '<span aria-hidden="true">&times;</span>' +
        '</button>' +
        '<h4 id= "lblTitleConfirmYesNo" class="modal-title" > Confirmation</h4 > ' +
        '</div > ' +
        '<div class="modal-body" > ' +
        '<p id="lblMsgConfirmYesNo"></p > ' +
        '<p id="lblMsgConfirmYesNo1"></p > ' +
        '</div > ' +
        '<div class="modal-footer" style="text-align: center; padding-bottom: 0px; border-top:0px;"> ' +
        '<button id= "btnNoConfirmYesNo" type= "button" class="btn btn-default btn-lg" >No, Cancel</button>' +
        '<button id= "btnYesConfirmYesNo" type= "button" class="btn btn-success btn-lg" >Yes, Proceed</button>' +   
        '<p id="pMsgConfirmYesNo" class="noteMsg"></p>'+
        '</div> ' +
        '</div> ' +
        '</div> ' +
        '</div>');

    $div.appendTo('body');
    var $confirm = $("#modalConfirmYesNo");
    $confirm.modal('show');
    $("#lblTitleConfirmYesNo").html("");
    //$("#lblTitleConfirmYesNo").html(title);
    $("#pMsgConfirmYesNo").html(title);
    $("#lblMsgConfirmYesNo").html(splitString(msg, '.')[0] + "."); //splitString use due to custom logic
    $("#lblMsgConfirmYesNo1").html(splitString(msg, '.')[1]);

    $("#btnYesConfirmYesNo").off('click').click(function () {
        yesFn(data);
        $confirm.modal("hide");
    });

    $("#btnNoConfirmYesNo").off('click').click(function () {
        //noFn();
        $confirm.modal("hide");
    });
}

//GET PARAMETER FROM URL
var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};

//CHECK IF A STRING STARTS WITH HTTP USING JAVASCRIPT
function isValidURL(text) {
    return /\b(http|https)/.test(text);
}

function AutoPopulateforCompany(controlId, PRESELECTED_COMPANY) {
    //Auto Populate for Cities
    $("#" + controlId).val('');
    $("#" + controlId).select2({
        //PLACEHOLDER: "SELECT COMPANY",
        multiple: false,
        minimumInputLength: 2,
        ajax: { // INSTEAD OF WRITING THE FUNCTION TO EXECUTE THE REQUEST WE USE SELECT2'S CONVENIENT HELPER
            url: "/Common/PopulateCompanies",
            dataType: 'json',
            quietMillis: 250,
            data: function (term, page) {
                return {
                    term: term, // search term
                };
            },
            results: function (data, page) { // parse the results into the format expected by Select2.
                // since we are using custom formatting functions we do not need to alter the remote JSON data
                return { results: data.Results };
            },
            cache: true
        }
    })
    if (PRESELECTED_COMPANY != undefined && PRESELECTED_COMPANY.id != 0)
        $("#" + controlId).select2('data', PRESELECTED_COMPANY);
}

function onlyLettersInput() {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                var transformedInput = text.replace(/[^a-zA-Z ]/g, '');
                //console.log(transformedInput);
                if (transformedInput !== text) {
                    ngModelCtrl.$setViewValue(transformedInput);
                    ngModelCtrl.$render();
                }
                return transformedInput;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
    };
};

app.directive('onlyLettersInput', onlyLettersInput);

app.directive('digitsOnly', allowOnlyNumbers);

function allowOnlyNumbers() {
    return {
        require: 'ngModel',
        restrict: 'A',
        link: function (scope, element, attr, ctrl) {
            function inputValue(val) {
                if (val) {
                    var digits = val.replace(/[^0-9]/g, '');
                    if (digits !== val) {
                        ctrl.$setViewValue(digits);
                        ctrl.$render();
                    }
                    return parseInt(digits, 10);
                }
                return undefined;
            }
            ctrl.$parsers.push(inputValue);
        }
    };
}

app.factory('subdomain', ['$location', function ($location) {
    var host = $location.host();
    var protocol = $location.protocol();
    //console.log(protocol);
    if (protocol === 'http') {
        host = "http://" + host;
    } else {
        host = "https://" + host;
    }
    return host;
}]);

app.directive('disallowSpecialCharacter', function () {
    return {
        require: 'ngModel',
        restrict: 'A',
        link: function (scope, element, attrs, modelCtrl) {
            modelCtrl.$parsers.push(function (input) {
                if (input == null)
                    return ''

                cleanInputValue = input.replace(/[^\w\s]/gi, '');

                if (cleanInputValue != input) {
                    modelCtrl.$setViewValue(cleanInputValue);
                    modelCtrl.$render();
                }

                return cleanInputValue;
            });
        }
    }
});

app.directive('jqdatepicker', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, element, attrs, ngModelCtrl) {
            element.datepicker({
                dateFormat: 'DD, d  MM, yy',
                onSelect: function (date) {
                    scope.date = date;
                    scope.$apply();
                }
            });
        }
    };
});

//Methods for return javascript date formatt - mm-dd-yyyy, mm/dd/yyyy or dd-mm-yyyy, dd/mm/yyyy
var dateFormattMMDDYYY = function (yourDate) {
    var date = new Date(yourDate);
    var dd = date.getDate();

    var mm = date.getMonth() + 1;
    var yyyy = date.getFullYear();
    if (dd < 10) {
        dd = '0' + dd;
    }

    if (mm < 10) {
        mm = '0' + mm;
    }

    date = dd + '/' + mm + '/' + yyyy;

    return date;
}

var getCurretDate = function () {
    //create a date/time string to be used in the file name
    var nowDate = new Date();
    var currentDateTimeString = nowDate.getMonth() + 1 + '-'
        + nowDate.getDate() + '-'
        + nowDate.getFullYear() + '-'
        + nowDate.getHours()
        + nowDate.getMinutes()
        + nowDate.getSeconds();

    return currentDateTimeString;
}

var capitalize = function (string) {
    if (string !== undefined && string.length > 0) {
        var splitStr = string.split(" ");
        for (var i = 0; i < splitStr.length; i++) {
            var j = splitStr[i].charAt(0).toUpperCase();
            splitStr[i] = j + splitStr[i].substr(1).toLowerCase();
        }

        return splitStr.join(" ");
    }
}

var redirectToOffers = function (url_token) {
    window.location.href = "/Customer/LoanApplicationResult/?webtoken=" + url_token;
}

//THE BELOW METHOD IS USED TO UPDATE THE META TAG FROM HEADER.
var updateMetaTag = function (id) {
    var meta = document.getElementById(id);
    meta.setAttribute("content", "width=device-width, initial-scale=1.0");
}

//START DATE CONSTRUCTOR
//CONVER DATE TO DD/MM/YYYY FORMATT
var dateToDMY = function (date) {
    if (date != undefined && date != null && date != "") {
        var dd = zerofill(date.getDate());
        var mm = zerofill(date.getMonth() + 1); //Month from 0 to 11, so added 1 months
        var yyyy = date.getFullYear();

        return dd + '/' + mm + '/' + yyyy; //DD/MM/YYYY //eg. 15/03/1984
    }
}

//IF MONTH AND DAY LESS THEN 9, IT SHOULD BE 01, 02,...,09
var zerofill = function (i) {
    if (i != undefined)
        return (i < 10 ? '0' : '') + i;
}
//END DATE CONSTRUCTOR

// GET URL PARAMETER VALUE BY NAME
var getURLSearchParams = function (parameterName) {
    var result = null,
        tmp = [];
    location.search
        .substr(1)
        .split("&")
        .forEach(function (item) {
            tmp = item.split("=");
            if (tmp[0] === parameterName) result = decodeURIComponent(tmp[1]);
        });
    return result;
}
//END

//GENERATE RANDOM NUMBER
function generateNumber(length) {
    var chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        result = ""
    for (var i = length; i > 0; --i)
        result += chars[Math.round(Math.random() * (chars.length - 1))]
    return result
}
//END

function genNumber() {
    var num = Math.floor(1000 + Math.random() * 9000);
    return num;
}

//ADD LENDER DETAILS - PLACEHOLDER FIELD SET
$(".placeholder").change(function () {
    if ($(this).val() !== "" && $(this).val() !== "-1") {
        $(this).addClass("hascontent");
    }
    else {
        $(this).removeClass("hascontent");
    }
});

//ADDED/REMOVED DAYS IN YOUR GIVEN DATE.
var addDays = function (theDate, days) {
    return new Date(theDate.getTime() + days * 24 * 60 * 60 * 1000);
}

//T.UK REDIRECT URL
var tukRedirectURL = function (responseData) {
    var redirectURL = responseData.RedirectUrl;
    //CHECK IF A STRING STARTS WITH HTTP
    if (!isValidURL(redirectURL))
        redirectURL = "http://" + redirectURL;

    window.location.href = redirectURL;
}

var dealInterval;
var count = 0;
//Hurry up! Deal ends in - section
var endDealsTimer = function (cdDatem, ids, grpName) {
    if (cdDatem != undefined && cdDatem != null && cdDatem != "") {
        // Set the date we're counting down to
        var countDownDate = new Date(cdDatem).getTime();
        
        //some landers not provided the deal end date - that time we getFullYear = 9999.
        // Update the count down every 1 second
        dealInterval = setInterval(function () {
            //count++;
            // Get today's date and time
            var now = new Date().getTime();

            // Find the distance between now and the count down date
            var distance = countDownDate - now;

            // Time calculations for days, hours, minutes and seconds
            var days = Math.floor(parseInt(distance) / (1000 * 60 * 60 * 24));
            var hours = Math.floor((parseInt(distance) % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((parseInt(distance) % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((parseInt(distance) % (1000 * 60)) / 1000);

            // Output the result in an element with id="offerEnds"
            var elementIds = document.getElementById("offerEnds" + ids + grpName);
            if (elementIds != undefined) {
                elementIds.innerHTML = days + "d " + hours + "h " + minutes + "m " + seconds + "s ";

                // If the count down is over, write Expired text
                if (distance < 0) {
                    clearInterval(dealInterval);
                    elementIds.innerHTML = "Expired";
                    $('#' + ids + 'Q' + grpName).text('Expired').addClass('pointernone loanExpired');
                    $('#expiredOffer' + ids + grpName).text('This Loan Offer is expired.');                    
                }
            }
        }, 1000);
    }
}
//End -  Hurry up! Deal Expired

//Check null or empty string
var isNullOrEmpty = function (value) {
    return !(typeof value === "string" && value.length > 0);
}

//Compare item ids of items and return name.
var getDDLSelectedText = function (items, itemId) {
    if (itemId > 0) {
        return (items.filter(function (item) { return item.ID === itemId; })[0]).Name;
    } else {
        return null;
    }
}

var getFullYear = function (date) {
    if (date != undefined && date != null && date !="") {
        return new Date(date).getFullYear();
    }
}

//SECTION CONECTIA - PERSONAL AND GUARANTOR LOAN ARRAY
var conectia_PersonalLoan = [
    { "MinLoanAmount": 1000, "MaxLoanAmount": 1999, "AvailableCashback": 10, "TierOfferID": "Offer1"     ,"EventID": 431},
    { "MinLoanAmount": 2000, "MaxLoanAmount": 2999, "AvailableCashback": 20, "TierOfferID": "Offer2"     ,"EventID": 432},
    { "MinLoanAmount": 3000, "MaxLoanAmount": 3999, "AvailableCashback": 30, "TierOfferID": "Offer3"     ,"EventID": 433},
    { "MinLoanAmount": 4000, "MaxLoanAmount": 4999, "AvailableCashback": 40, "TierOfferID": "Offer4"     ,"EventID": 434},
    { "MinLoanAmount": 5000, "MaxLoanAmount": 7499, "AvailableCashback": 50, "TierOfferID": "Offer5"     ,"EventID": 435},
    { "MinLoanAmount": 7500, "MaxLoanAmount": 9999, "AvailableCashback": 75, "TierOfferID": "Offer6"     ,"EventID": 436},
    { "MinLoanAmount": 10000, "MaxLoanAmount": 14999, "AvailableCashback": 100, "TierOfferID": "Offer7"  ,"EventID": 437},
    { "MinLoanAmount": 15000, "MaxLoanAmount": 19999, "AvailableCashback": 150, "TierOfferID": "Offer8"  ,"EventID": 438},
    { "MinLoanAmount": 20000, "MaxLoanAmount": 29999, "AvailableCashback": 200, "TierOfferID": "Offer9"  ,"EventID": 439},
    { "MinLoanAmount": 30000, "MaxLoanAmount": 35000, "AvailableCashback": 300, "TierOfferID": "Offer10", "EventID": 440}
];

var conectia_GuarantorLoan = [
    { "MinLoanAmount": 1000, "MaxLoanAmount": 1999, "AvailableCashback": 10, "TierOfferID": "Offer11" , "EventID": 441},
    { "MinLoanAmount": 2000, "MaxLoanAmount": 2999, "AvailableCashback": 20, "TierOfferID": "Offer12" , "EventID": 442},
    { "MinLoanAmount": 3000, "MaxLoanAmount": 3999, "AvailableCashback": 30, "TierOfferID": "Offer13" , "EventID": 443},
    { "MinLoanAmount": 4000, "MaxLoanAmount": 4999, "AvailableCashback": 40, "TierOfferID": "Offer14" , "EventID": 444},
    { "MinLoanAmount": 5000, "MaxLoanAmount": 5999, "AvailableCashback": 50, "TierOfferID": "Offer15" , "EventID": 445},
    { "MinLoanAmount": 6000, "MaxLoanAmount": 6999, "AvailableCashback": 60, "TierOfferID": "Offer16" , "EventID": 446},
    { "MinLoanAmount": 7000, "MaxLoanAmount": 7999, "AvailableCashback": 70, "TierOfferID": "Offer17" , "EventID": 447},
    { "MinLoanAmount": 8000, "MaxLoanAmount": 10000, "AvailableCashback": 80, "TierOfferID": "Offer18", "EventID": 448}
];

var filterConectiaItems = function (items, filter) {
    if (items.length > 0 && filter != undefined) {
        return items.filter(item => (item.MinLoanAmount <= filter && item.MaxLoanAmount >= filter));
    }
}
//END SECTION CONECTIA