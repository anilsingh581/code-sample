﻿using getAddress.Sdk;
using getAddress.Sdk.Api.Requests;
using getAddress.Sdk.Api.Responses;
using Logger;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Models;
using Newtonsoft.Json;
using Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebAPIHelper;

namespace WebApp.Controllers
{
    public class CustomerController : Controller
    {
        #region ConfigurationManager - AppSettings

        private static string LocalUser_HostAddress = string.Empty;
        private string lenderRedirectURL = string.Empty;

        #endregion
        IConfiguration config = null;
        IBorrower borrowerHelper = null;
        ICommonHelper commonHelper = null;
        IAES aes = null;
        private readonly IHttpContextAccessor httpContextAccessor;
        public CustomerController(IConfiguration _config, IBorrower borrower, ICommonHelper _commonHelper, IAES _aes, IHttpContextAccessor _httpContextAccesso)
        {

            borrowerHelper = borrower;
            commonHelper = _commonHelper;
            config = _config;
            aes = _aes;
            httpContextAccessor = _httpContextAccesso;
            LocalUser_HostAddress = _config.GetValue<string>("LocalUserHostAddress");

        }

        public ActionResult LoanApplication(string id = "0")
        {
            int loanAppId = Convert.ToInt32(id.Replace(aes.GetJSSecretKey(), ""));
            ViewBag.LoanApplicationId = loanAppId == 0 ? 0 : loanAppId;

            return View("LoanApplication");
        }

        public ActionResult viewloandetails()
        {
            return View();
        }

        public ActionResult ViewLoanApplicationDetail()
        {
            return View();
        }

        public ActionResult Login()
        {
            return RedirectToAction("LoanApplication", "Customer");
        }

        /// <summary>
        /// LOAN APPLICATION RESULT ACTION
        /// </summary>
        public ActionResult LoanApplicationResult(string webtoken)
        {
            try
            {
                //This one is custom token, we know the length =28 and it mist be 28 otherwise its is wrong! for this app;
                if (webtoken.Length == Loanc.TWENTY8)
                {
                    SecurityTokenHandler(webtoken);
                }
                else
                {
                    ViewBag.FilteredLoanAppId = Loanc.UTF8C;//do not remove this line.
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogMessage("LoanApplicationResult Action : " + ex.Message + " StackTrace : " + ex.StackTrace);
                return View();
            }
            return View();
        }

        /// <summary>
        /// THIS METHOD IS USED TO FILTER THE LOANAPPLICATIONID FROM TOKENHANDLER.
        /// </summary>
        /// <param name="secureToken"></param>
        private void SecurityTokenHandler(string secureToken)
        {
            ErrorLog.LogMessage("Loan Application Result Token : " + secureToken);
            try
            {
                string tokenID1, tokenID2 = string.Empty;
                tokenID1 = secureToken.Replace(aes.GetJSSecretKey(), "");
                tokenID2 = (tokenID1 != null && tokenID1 != Loanc.ZERO && tokenID1.Length > Loanc.TEN) ? tokenID1.Remove(0, Loanc.TEN) : Loanc.UTF8C;
                ViewBag.FilteredLoanAppId = tokenID2; //This ViewBag is used for disply Offer on Result page.

                ErrorLog.LogMessage("Loan Application Result -> loanApplicationId:" + tokenID2);
            }
            catch (Exception ex)
            {
                ErrorLog.LogMessage("Error on SecurityTokenHandler : Message : " + ex.Message + ", StackTrace : " + ex.StackTrace);
            }
        }

        public ActionResult lender_deeplink(string lender, string offerId)
        {
            ViewBag.OfferId = offerId;
            ViewBag.LenderName = lender;
            return View();
        }

        public ActionResult<BorrowerModel> GetBorrowerTemplate(string LoanTerm, string LoanAmount, string APITokenID, string IPAddress, string Role, string LoanApplicationId)
        {
            BorrowerModel model = new BorrowerModel();

            return model;
        }

        public ActionResult GetBorrowerAddresses(string PostalCode)
        {
            string model = commonHelper.GetAddressesByPostalCode(PostalCode);

            return Ok(model);
        }

        [HttpGet]
        public async Task<ActionResult> GetBorrowerAddressesFromEquifaxAsync(string PostalCode)
        {
            ErrorLog.Error("Post Code Search : " + PostalCode, "Borrower controller", "AddressSearch");

            var apiKey = new ApiKey(config.GetValue<string>("AddressAPIKey"));
            bool getEquifaxAddressKey = Convert.ToBoolean(config.GetValue<string>("IsEnableEquifaxAddressKey"));

            AddressListModel model = new AddressListModel();

            if (getEquifaxAddressKey)
            {
                model = commonHelper.GetAddressesFromEquiFaxByPostalCode(PostalCode);

                //BELOW LINE OF CODE IS USED FOR DUMP ADDRESS IN DB
                //if(model != null)
                //    await Task.Factory.StartNew(() => commonHelper.SaveAddressList(model.AddressList));
            }
            else
            {
                List<AddressModel> AddressList = new List<AddressModel>();
                try
                {
                    using (var api = new GetAddesssApi(apiKey))
                    {
                        var result = await api.Address.Get(new GetAddressRequest(PostalCode, null, true));
                        if (result.IsSuccess)
                        {
                            var successfulResult = (GetAddressResponse.Success)result;
                            int count = 1;

                            foreach (var address in successfulResult.Addresses)
                            {
                                var HouseNumber = string.Empty;
                                var HouseName = string.Empty;
                                var Street1 = string.Empty;
                                //Check HouseNumber, Street1, and Full address using case 1, case 2, case 3
                                string Line1 = address.Line1;
                                bool isDigit = !string.IsNullOrEmpty(Line1) && Line1.Length > 0 && char.IsDigit(Line1[0]);
                                string fullAdress = PrepareNonEquifaxAddress(PostalCode, address, Line1, isDigit, ref HouseNumber, ref HouseName, ref Street1);

                                AddressList.Add(new AddressModel()
                                {
                                    EquifaxAddressID = Convert.ToString(count),
                                    FullAddress = fullAdress,
                                    HouseNumber = HouseNumber,
                                    HouseName = HouseName,
                                    Street1 = Street1,
                                    PostTown = (address.TownOrCity.Trim().Length > 0) ? address.TownOrCity.TrimStart() : address.TownOrCity,
                                    District = (address.County.Trim().Length > 0) ? address.County.TrimStart() : address.TownOrCity,
                                    County = (address.County.Trim().Length > 0) ? address.County.TrimStart() : address.TownOrCity,
                                    PostCode = PostalCode,
                                    Country = "United Kingdom",//Country not avaliable in GetAddressResponse so added this text.
                                    City = (address.TownOrCity.Trim().Length > 0) ? address.TownOrCity.TrimStart() : address.TownOrCity
                                });
                                count++;
                            }
                            model.AddressList = AddressList;
                            //BELOW LINE OF CODE IS USED FOR DUMP ADDRESS IN DB
                            // await Task.Factory.StartNew(()=>  commonHelper.SaveAddressList(AddressList));
                        }
                        else
                        {
                            model = commonHelper.GetAddressesFromEquiFaxByPostalCode(PostalCode);

                            //BELOW LINE OF CODE IS USED FOR DUMP ADDRESS IN DB
                            //if (model != null)
                            //    await Task.Factory.StartNew(() => commonHelper.SaveAddressList(model.AddressList));
                        }
                    }
                }
                catch (Exception ex)
                {
                    ErrorLog.Error("StackTrace -" + ex.StackTrace + "Message - " + ex.Message, "Borrower controller", "GetBorrowerAddressesFromEquifaxAsync");
                }
            }

            return Ok(model);
        }

        /// <summary>
        /// PREPARE FULL ADDRESS FOR NOT EQUIFAX APIs
        /// </summary>
        private static string PrepareNonEquifaxAddress(string PostalCode, Address address, string Line1, bool isDigit, ref string HouseNumber, ref string HouseName, ref string Street1)
        {
            Street1 = (address.Line2.Length > 1) ? (address.Line1 + ", " + address.Line2) : address.Line1;

            #region prepare full address for not equifax address list
            string fullAddress = getfullAddress(PostalCode, address, ref Street1);

            string[] lineArray = { "unit", "flat", "apartment", "apt", "block" };
            string lineToCheck = address.Line1.Length > 0 ? address.Line1.ToLower() : "";
            var line2 = address.Line2.Length > 0 ? address.Line2.TrimStart() : "";
            bool isDigit4 = !string.IsNullOrEmpty(line2) && line2.Length > 0 && char.IsDigit(line2[0]);
            bool isLineMatched = lineArray.Any(l => lineToCheck.Contains(l));
            #endregion

            //BLOW CUSTOM RULES AS PER BOSS.
            //CASE 1
            //SOME TIME HOUSENUMBER IS EXIST IN ADDRESS.LINE1 AT THE 1ST CHAR.
            //CHECK THE ADDRESS LINE1 IS CONTAINS THE 1ST CHAR DIGIT OR NOT.
            if (isDigit)
                getCase1HouseNumber(address, Line1, isDigit, ref HouseNumber, ref HouseName, ref Street1);

            //CASE 2
            //SOME TIME HOUSENUMBER WITH UNIT, FLAT, APARTMENT, APT, BLOCK IN THE ADDRESS.LINE2
            //CHECK UNIT, FLAT, APARTMENT, APT, BLOCK IS EXISTS IN ADDRESS.LINE1
            //SET UNIT + NUMBER IN HOUSENUMBER        
            if (!isDigit && !isDigit4 && isLineMatched)
                getCase2HouseNumber(address, Line1, isDigit, ref HouseNumber, ref HouseName, ref Street1, lineArray, lineToCheck);

            //CASE 3
            //SOME TIME HOUSENUMBER IS EXIST IN ADDRESS.LINE2
            //CHECK HOUSENUMBER IS AVAILABLE IN ADDRESS.LINE2
            if (!isDigit && !isLineMatched)
                getCase3HouseNumber(address, isDigit, ref HouseNumber, ref HouseName, ref Street1);

            //CASE 4
            //SOME TIME HOUSENUMBER IS EXIST IN ADDRESS.LINE1 AS LIKE UNIT, FALT ETC.
            //ALSO AVAILABLE IN ADDRESS.LINE2, PIC HOUSENUMBER FROM ADDRESS.LINE1 / FLAT, UNIT ETC.
            if (!isDigit && isDigit4 && isLineMatched)
                getCase4HouseNumber(address, Line1, out HouseNumber, out HouseName, out Street1);

            return fullAddress;
        }

        /// <summary>
        /// PREPARE FULL ADDRESS FOR NOT EQUIFAX ADDRESS LIST
        /// </summary>
        private static string getfullAddress(string PostalCode, Address address, ref string Street1)
        {
            return NotEquifaxFullAddress(PostalCode, address, ref Street1);
        }

        /// <summary>
        /// SOME TIME HOUSENUMBER IS EXIST IN ADDRESS.LINE1 AT THE 1ST CHAR.
        /// CHECK THE ADDRESS LINE1 IS CONTAINS THE 1ST CHAR DIGIT OR NOT.
        /// </summary>
        private static void getCase1HouseNumber(Address address, string Line1, bool isDigit, ref string HouseNumber, ref string HouseName, ref string Street1)
        {
            try
            {
                if (isDigit)
                {
                    //get:set property
                    HouseNumber = (Line1.Length > 0) ? Line1.Split()[0] : "";
                    Street1 = (Line1.Length > 0) ? ((address.Line1).Replace(HouseNumber, "")).TrimStart() : "";
                    Street1 = (address.Line2.Length > 1) ? Street1 + ", " + address.Line2 : Street1;
                    HouseName = Street1;
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogException(ex);
            }
        }

        /// <summary>
        /// SOME TIME HOUSENUMBER WITH UNIT, FLAT, APARTMENT, APT, BLOCK IN THE ADDRESS.LINE2
        /// CHECK UNIT, FLAT, APARTMENT, APT, BLOCK IS EXISTS IN ADDRESS.LINE1
        /// SET UNIT + NUMBER IN HOUSENUMBER
        /// </summary>       

        private static void getCase2HouseNumber(Address address, string Line1, bool isDigit, ref string HouseNumber, ref string HouseName, ref string Street1, string[] lineArray, string lineToCheck)
        {
            try
            {
                if (!isDigit)
                {
                    if (lineArray.Any(l => lineToCheck.Contains(l)))
                    {
                        HouseNumber = (Line1.Length > 0) ? Line1 : "";
                        Street1 = (address.Line2.Length > 0) ? address.Line2.TrimStart() : "";
                        Street1 = (Street1.Length > 1) ? Street1 + ", " + address.Line3 : Street1;
                        HouseName = Street1;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogException(ex);
            }
        }

        /// <summary>
        /// SOME TIME HOUSENUMBER IS EXIST IN ADDRESS.LINE2
        /// CHECK HOUSENUMBER IS AVAILABLE IN ADDRESS.LINE2
        /// </summary>
        private static void getCase3HouseNumber(Address address, bool isDigit, ref string HouseNumber, ref string HouseName, ref string Street1)
        {
            try
            {
                if (!isDigit)
                {
                    //get:set property
                    var line2 = address.Line2.Length > 0 ? address.Line2.TrimStart() : address.Line2;
                    bool isDigit2 = !string.IsNullOrEmpty(line2) && line2.Length > 0 && char.IsDigit(line2[0]);
                    if (isDigit2)
                    {
                        HouseNumber = (line2.Length > 0) ? line2.Split()[0] : "";
                        Street1 = (line2.Length > 0) ? (line2).TrimStart() : "";
                        Street1 = (address.Line1.Length > 1) ? address.Line1 + ", " + Street1 : Street1;
                        HouseName = Street1;
                    }
                    else
                    {
                        HouseNumber = (line2.Length > 0) ? line2.Split()[0] : "";
                        Street1 = (line2.Length > 0) ? (line2).TrimStart() : "";
                        Street1 = (address.Line1.Length > 1) ? address.Line1 + ", " + Street1 : Street1;
                        HouseName = Street1;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogException(ex);
            }
        }

        /// <summary>
        /// Some time HouseNumber is exist in address.Line1 as like Unit, falt etc.
        /// Also available in address.Line2, pic HouseNumber from address.Line1 / flat, unit etc.
        /// </summary>
        private static void getCase4HouseNumber(Address address, string Line1, out string HouseNumber, out string HouseName, out string Street1)
        {
            HouseNumber = (Line1.Length > 0) ? Line1 : "";
            Street1 = (address.Line2.Length > 0) ? address.Line2.TrimStart() : "";
            Street1 = (Street1.Length > 1) ? Street1 + ", " + address.Line3 : Street1;
            HouseName = Street1;
        }

        /// <summary>
        /// PREPARE FULL ADDRESS FOR NOT EQUIFAX ADDRESS LIST
        /// </summary>
        private static string NotEquifaxFullAddress(string PostalCode, Address address, ref string Street1)
        {
            var addLocality = (address.Locality != null) ? address.Locality.Trim() : address.Locality;
            var addTownOrCity = (address.TownOrCity != null) ? address.TownOrCity.Trim() : address.TownOrCity;
            var addCounty = (address.County != null) ? address.County.Trim() : address.County;

            //concatenate address properties for full address
            var fullAddress = Street1 + ", "
                + (addLocality = (addLocality.Length > 0) ? addLocality + ", " : "")
                + (addTownOrCity = (addTownOrCity.Length > 0) ? addTownOrCity + ", " : "")
                + (addCounty = (addCounty.Length > 0) ? addCounty + ", " : "")
                + PostalCode;
            return fullAddress;
        }


        [HttpPost]
        public ActionResult<ResponseModel> ValidateViewLoanApplication([FromBody]LoanVerificationReqModel LoanVerificationReq)
        {
            ResponseModel model = new ResponseModel();
            try
            {
                if (LoanVerificationReq.LoanApplicationID != null)
                {
                    var secureAppLoanID = (LoanVerificationReq.LoanApplicationID.Length > 8)
                                            ? (LoanVerificationReq.LoanApplicationID.Remove(0, 4)) : "0";
                    secureAppLoanID = (secureAppLoanID.Length > 4)
                                    ? (secureAppLoanID.Remove(secureAppLoanID.Length - 4)) : "0";
                    LoanVerificationReq.LoanApplicationID = secureAppLoanID;
                }
                else
                {
                    LoanVerificationReq.LoanApplicationID = "0";
                }

                model = borrowerHelper.ValidateViewLoanApplication(LoanVerificationReq);
                model.ReturnValue = (model.ReturnValue != null ? Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(model.ReturnValue)) : Loanc.UTF8C);

                if (model.Message == "UNAUTHORIZED")
                    RedirectToAction("RemoveAuthetication", "Account");

                return model;
            }
            catch (Exception ex)
            {
                ErrorLog.Error("Message : " + ex.Message + ", StackTrace : " + ex.StackTrace, typeof(BorrowerHelper).Name, "ValidateViewLoanApplication");
                model.Status = false;
                model.ReturnValue = Loanc.UTF8C;
                return model;
            }            
        }

        [HttpPost]
        public ActionResult<ResponseModel> SaveLoanApplication([FromBody]BorrowerModel LoanApplication)
        {
            ResponseModel model = new ResponseModel();
            try
            {
                string IPAddress = LoanApplication.ReturnValue;
                string remoteIp = HttpContext.Features.Get<IHttpConnectionFeature>().RemoteIpAddress.ToString();
                string ExternalIP = ((remoteIp == "::1") || (remoteIp == "127.0.0.1")) ? aes.EncryptStringAES(LocalUser_HostAddress) : aes.EncryptStringAES(remoteIp);
                LoanApplication.RegistrationID = User.Identity.IsAuthenticated == true ? User.Identity.Name : "0";
                LoanApplication.LoanApplicationDetail.BankAccountNumber = string.IsNullOrEmpty(LoanApplication.LoanApplicationDetail.BankAccountNumber) ? "01234567" : LoanApplication.LoanApplicationDetail.BankAccountNumber;
                LoanApplication.LoanApplicationDetail.BankSortNumber = string.IsNullOrEmpty(LoanApplication.LoanApplicationDetail.BankSortNumber) ? "012345" : LoanApplication.LoanApplicationDetail.BankSortNumber;
                LoanApplication.UserAgent = Request.Headers["User-Agent"].ToString();
                LoanApplication.LoanApplicationDetail.WebConnectRequestID = LoanApplication.LoanApplicationDetail.WebConnectRequestID == "null" ? null : LoanApplication.LoanApplicationDetail.WebConnectRequestID;
                
                //CHECK AND SET LOAN APPLICATION DETAIL FIELDS
                SetLoanApplicationDetailFields(LoanApplication, ExternalIP);

                model = borrowerHelper.SaveLoanApplication(LoanApplication, IPAddress, ExternalIP);
                model.ReturnValue = (model.ReturnValue != null ? Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(model.ReturnValue)) : Loanc.UTF8C);

                if (model.Message == "UNAUTHORIZED")
                    RedirectToAction("RemoveAuthetication", "Account");

                return model;
            }
            catch (Exception ex)
            {
                ErrorLog.Error("Message : " + ex.Message + ", StackTrace : " + ex.StackTrace, typeof(BorrowerHelper).Name, "SaveLoanApplication");
                model.Status = false;
                model.ReturnValue = Loanc.UTF8C;
                return model;
            }           
        }

        /// <summary>
        /// CHECK AND SET LOAN APPLICATION DETAIL FIELDS
        /// </summary>
        private void SetLoanApplicationDetailFields(BorrowerModel LoanApplication, string ExternalIP)
        {
            string remoteIp = HttpContext.Features.Get<IHttpConnectionFeature>().RemoteIpAddress.ToString();


            var loanDetail = LoanApplication.LoanApplicationDetail;
            var empDetail = LoanApplication.EmployerDetail;

            loanDetail.OtherMonthlyExpense = loanDetail.OtherMonthlyExpense ?? "0";
            loanDetail.OtherMonthlyIncome = loanDetail.OtherMonthlyIncome ?? "0";

            empDetail.EmploymentLengthInYears = empDetail.EmploymentLengthInYears ?? "0";
            empDetail.EmploymentLengthInMonths = empDetail.EmploymentLengthInMonths ?? "0";

            //GET AND SET GEO LOACTION
            string str = commonHelper.GetGeoLocation(aes.DecryptStringAES(ExternalIP));
            UserLocation loc = JsonConvert.DeserializeObject<UserLocation>(str);

            loanDetail.IntIPAddress = remoteIp;
            loanDetail.ExtIPAddress = aes.DecryptStringAES(ExternalIP);

            loanDetail.GeoLocation = $"city:{loc.city},country:{loc.country_name},latitude:{loc.latitude},longitude:{loc.longitude}";
        }

        /// <summary>
        /// Get LoanApplication Result | Loan/ShowQuotes/{Id}
        /// </summary>
        [HttpPost]
        public ActionResult<LenderMatchListModel> GetLoanApplicationResult([FromBody] dynamic LoanApplicationId)
        {
            LenderMatchListModel model = new LenderMatchListModel();
            try
            {
                var LoanAppId = LoanApplicationId.LoanApplicationId.ToString();
                ErrorLog.Error("Encoding LoanApplicationId : " + LoanAppId + ", RequestModel Obj : ", typeof(BorrowerHelper).Name, "API Request: Loan/ShowQuotes/");
                             
                ErrorLog.LogMessage($"LoanApplicationId :  {LoanAppId}  API Request: Loan/ShowQuotes/");
                LoanAppId = Encoding.UTF8.GetString(Convert.FromBase64String(LoanAppId));

                model = borrowerHelper.GetLoanApplicationResult(LoanAppId);

                model.ReturnValue = (model.ReturnValue != null ? Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(model.ReturnValue)) : Loanc.UTF8C);

                if (model != null && model.Message == "UNAUTHORIZED")
                    RedirectToAction("RemoveAuthetication", "Account");

                ErrorLog.Error("LoanApplicationId : " + LoanAppId + ", ResponseModel Obj : ", typeof(BorrowerHelper).Name, "API Response: Loan/ShowQuotes/");
                return model;
            }
            catch (Exception ex)
            {
                ErrorLog.Error("Message : " + ex.Message + ", StackTrace : " + ex.StackTrace, typeof(BorrowerHelper).Name, "API Response: Loan/ShowQuotes/");
                model.Status = false;
                model.ReturnValue = Loanc.UTF8C;
                return model;
            }

        }


        [HttpPost]
        public ActionResult<ResponseModel> ResubmitLoanApplication([FromBody]ModifiedLoanApplicationModel LoanApplication)
        {
            //string IPAddress = obj.InternalIP;
            //string remoteIp = HttpContext.Features.Get<IHttpConnectionFeature>().RemoteIpAddress.ToString();
            //string ExternalIP = ((remoteIp == "::1") || (remoteIp == "127.0.0.1")) ? aes.EncryptStringAES(LocalUser_HostAddress) : aes.EncryptStringAES(remoteIp);

            ErrorLog.Error("Encoding LoanApplicationId for ResubmitLoanApplication : " + LoanApplication.LoanAppID + ", RequestModel Obj : ", typeof(BorrowerHelper).Name, "ResubmitLoanApplication");
            LoanApplication.LoanAppID = Encoding.UTF8.GetString(Convert.FromBase64String(LoanApplication.LoanAppID));

            ErrorLog.Error("LoanApplicationId : " + LoanApplication.LoanAppID + ", RequestModel Obj : ", typeof(BorrowerHelper).Name, "ResubmitLoanApplication");

            ResponseModel model = borrowerHelper.ResubmitLoanApplicationResult(LoanApplication);
            model.ReturnValue = (model.ReturnValue != null ? Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(model.ReturnValue)) : Loanc.UTF8C);

            if (model.Message == "UNAUTHORIZED")
                RedirectToAction("RemoveAuthetication", "Account");

            return Ok(model);
        }




        /// <summary>
        /// THIS METHOD IS USED TO ACCEPT THE QUATE
        /// </summary>
        [HttpPost]
        public ActionResult<LoanTubeAPIResponseModel> LoanAggrement([FromBody] dynamic data)
        {
            try
            {
                var offerIdString = data.offerId.ToString();
              
                var offerId = Encoding.UTF8.GetString(Convert.FromBase64String(offerIdString));


                ErrorLog.LogMessage($"offerID: ({offerId}) LoanAgreement Request ");

                LoanTubeAPIResponseModel resmodel = borrowerHelper.CompleteLoanApplication(offerId);
                ErrorLog.LogMessage($"offerID: ({offerId}) LoanAgreement Response ");
                               

                return Ok(resmodel);
            }
            catch (Exception ex)
            {
                ErrorLog.Error(ex.Message + ", StackTrace :" + ex.StackTrace, typeof(BorrowerHelper).Name, "Loan Aggrement");
                return Ok(new LoanTubeAPIResponseModel());
            }
        }

        /// <summary>
        /// USED FOR LOGGING THE LOAN AGGREMENT 
        /// </summary>
        [HttpPost]
        public async Task<ActionResult> LoanAggrementLogs(string loanAppID, string loanRedirectingURL)
        {
            try
            {
                ErrorLog.LogMessage($"LoanApplicationID: ({loanAppID}) Redirecting to  {loanRedirectingURL} for loan application : {loanAppID}");

                return Ok();
            }
            catch (Exception ex)
            {
                ErrorLog.Error(ex.Message + ", StackTrace :" + ex.StackTrace, typeof(BorrowerHelper).Name, "Loan Aggrement Log");
                return Ok();
            }
        }

        /// <summary>
        /// Update Conectia Request
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public async Task<ActionResult> UpdateConectiaRequest([FromBody] LoanAgreement model)
        {
            try
            {
                ErrorLog.LogMessage($"UpdateConectiaRequest LoanApplicationID: ({model.LoanApplicationID}) and the Updated WebConnectRequest is : {model.LenderReferenceID}");

                Task<ResponseModel> resultModel = borrowerHelper.UpdateConectiaRequest(model);

                return Ok(resultModel);
            }
            catch (Exception ex)
            {
                ErrorLog.Error(ex.Message + ", StackTrace :" + ex.StackTrace, typeof(BorrowerHelper).Name, "UpdateConectiaRequest");
                return Ok(new ResponseModel());
            }
        }
    }
}