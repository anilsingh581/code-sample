﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;



namespace WebApp.Controllers
{
    public class ErrorsController : Controller
    {
        #region CONFIGURATIONMANAGER - APPSETTINGS

        private string ErrorMsg = string.Empty;
        #endregion

        #region "Call View Function"
        public ErrorsController(IConfiguration configuration)
        {
            ErrorMsg = configuration.GetValue<string>("ApplicationErrorMsg");
        }

        public ActionResult Index()
        {
            ViewBag.ErrorCode = Response.StatusCode;
            ViewBag.Message = ErrorMsg;

            return View();
        }

        public ActionResult General(Exception exception)
        {
            ViewBag.ErrorCode = Response.StatusCode;
            ViewBag.Message = ErrorMsg;

            return View("Index");
        }

        public ActionResult Http404()
        {
            ViewBag.ErrorCode = Response.StatusCode;
            ViewBag.Message = ErrorMsg;

            return View("Index");
        }

        public ActionResult Http403()
        {
            ViewBag.Message = Response.StatusCode;
            ViewBag.Message = ErrorMsg;

            return View("Index");
        }
        #endregion
    }
}
