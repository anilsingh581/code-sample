﻿namespace Models
{
    public class AcceptQuoteModel
    {
        public string LoanTubeAcceptURL { get; set; }
        public string LoanApplicationID { get; set; }
        public string LenderAcceptURL { get; set; }
        public string LenderToken { get; set; }
        public string TokenID { get; set; }
    }
}
