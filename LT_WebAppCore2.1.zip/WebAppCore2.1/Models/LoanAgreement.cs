﻿namespace Models
{
    public class LoanAgreement : RequestModel
    {
        public int OfferID { get; set; }
        public string LoanApplicationID { get; set; }
        public string LenderAcceptURL { get; set; }
        public string LenderCode { get; set; }
        public string LenderToken { get; set; }
        public string LoanEMIAmount { get; set; }
        public string APR { get; set; }
        public int YodleeAgreementStatus { get; set; }
        public string ProductCampaignID { get; set; }
        public string ProductCode { get; set; }
        public string LenderProductType { get; set; }
        public string LenderReferenceID { get; set; }
    }

    public class ConectiaRequest : RequestModel
    {
        public string LoanApplicationID { get; set; }
        public string WebConnectRequestID { get; set; }
    }
}
