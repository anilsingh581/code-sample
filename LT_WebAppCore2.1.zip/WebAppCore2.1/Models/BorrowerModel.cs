﻿using System.Collections.Generic;

namespace Models
{
    public class BorrowerModel : ResponseModel
    {
        public string RegistrationID { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneNumber { get; set; }
        public string Password { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }
        public string BorrowerLoanAppID { get; set; }
        public string UserAgent { get; set; }
        public string DOB { get; set; }
        public string LatestPostCode { get; set; }
        public bool IsAddressFoundInEquifaxSearch { get; set; } = true;
        public List<BorrowerAddressModel> ResidentAddress { get; set; }
        public LoanModel LoanApplicationDetail { get; set; }
        public EmploymentModel EmployerDetail { get; set; }
        public List<AddressModel> AddressList { get; set; }

        public BorrowerModel()
        {
            RegistrationID = string.Empty;
            EmailAddress = string.Empty;
            PhoneNumber = string.Empty;
            Password = string.Empty;
            CompanyID = string.Empty;
            Title = string.Empty;
            FirstName = string.Empty;
            MiddleName = string.Empty;
            LastName = string.Empty;
            Gender = string.Empty;
            BorrowerLoanAppID = string.Empty;
            UserAgent = string.Empty;
            LoanApplicationDetail = new LoanModel();
            EmployerDetail = new EmploymentModel();
            ResidentAddress = new List<BorrowerAddressModel>();
        }
    }
}
