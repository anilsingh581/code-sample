﻿namespace Models
{
    public class LoanVerificationResModel : ResponseModel
    {
        public string RegistrationID { get; set; }
        public string LoanApplicationID { get; set; }
        public string Token { get; set; }
        public string LastName { get; set; }
        public string DateOfBirth { get; set; }
    }

    public class LoanVerificationReqModel : RequestModel
    {
        public string LoanApplicationID { get; set; }
        public string Token { get; set; }
        public string LastName { get; set; }
        public string DateOfBirth { get; set; }
    }
}
