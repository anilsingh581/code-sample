﻿using System.Collections.Generic;

namespace Models
{
    public class AddressListModel : ResponseModel
    {
        public List<AddressModel> AddressList { get; set; }
    }
}
