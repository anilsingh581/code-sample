﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Models
{
    public class BambooWebHookRequestModel : RequestModel
    {
        public string uuid { get; set; }
        public string sequence_number { get; set; }
        public string channel_ref { get; set; }
        public string channel_lead_ref { get; set; }
        public string lead_ref { get; set; }
        public string loan_application_ref { get; set; }

        [JsonProperty("event")]
        public string Event { get; set; }

        public string event_time { get; set; }
        public string status { get; set; }
    }

    public class ListBambooWebHookRequestModel : ResponseModel
    {
        public List<BambooWebHookRequestModel> LenderList { get; set; }
        public ListBambooWebHookRequestModel()
        {
            LenderList = new List<BambooWebHookRequestModel>();
        }
    }
}
