﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public interface IBorrower
    {
        ResponseModel ValidateViewLoanApplication(LoanVerificationReqModel model);
        ResponseModel SaveLoanApplication(BorrowerModel model, string InternalIP, string ExternalIP);
        ResponseModel ResubmitLoanApplicationResult(ModifiedLoanApplicationModel model);
        LoanTubeAPIResponseModel CompleteLoanApplication(string offerID);
        Task<ResponseModel> UpdateConectiaRequest(LoanAgreement model);
        Task<ResponseModel> PushConectiaRequest(LoanAgreement model);

        LenderMatchListModel GetLoanApplicationResult(string LoanId);

    }
}
