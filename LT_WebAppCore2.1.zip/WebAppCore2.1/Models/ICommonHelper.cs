﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models
{
   public interface ICommonHelper
    {
        string GetAddressesByPostalCode(string postalCode);
        string GetGeoLocation(string IPAddress);
        AddressListModel GetAddressesFromEquiFaxByPostalCode(string postalCode);
        void SaveAddressList(List<AddressModel> addressList);
        ResponseModel LenderWebhook(BambooWebHookRequestModel model);
    }
}
