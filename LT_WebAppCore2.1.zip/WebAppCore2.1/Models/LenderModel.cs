﻿using System.Collections.Generic;

namespace Models
{
    public class LenderModel : ResponseModel
    {
        public string CompanyID { get; set; }
        public string CompanyUniqueID { get; set; }
        public string CompanyName { get; set; }
        public string FullAddress { get; set; }
        public string CityName { get; set; }
        public string PhoneNumber { get; set; }
        public string WebsiteAddress { get; set; }
        public string Company_logo_url { get; set; }
        public bool IsActive { get; set; }
        public int ActiveUsers { get; set; }
        public int PendingUsers { get; set; }
        public string LenderAdminEmail { get; set; }
        public int LenderProducts { get; set; }
    }

    public class ListLenderModel : ResponseModel
    {
        public List<LenderModel> LenderList { get; set; }
        public ListLenderModel()
        {
            LenderList = new List<LenderModel>();
        }
    }

    public class LoanFilterModel : RequestModel
    {
        public string LoanApplicationID { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PostCode { get; set; }
        public string LoanStatusIDs { get; set; }
        public string MinLoanAmount { get; set; }
        public string MaxLoanAmount { get; set; }
        public string ResidentialStatusID { get; set; }
    }

    public class LoanStatusUpdateModel : RequestModel
    {
        public string LoanApplicationID { get; set; }
        public string LoanStatusID { get; set; }
        public string Remark { get; set; }
    }
}