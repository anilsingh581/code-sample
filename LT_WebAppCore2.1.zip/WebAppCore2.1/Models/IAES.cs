﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models
{
    public interface IAES
    {
        string GetJSSecretKey();
        string EncryptStringAES(string cipherText);
        string DecryptStringAES(string cipherText);
    }
}
