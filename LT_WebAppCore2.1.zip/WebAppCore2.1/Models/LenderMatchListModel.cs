﻿using System;
using System.Collections.Generic;

namespace Models
{
    public class LenderMatchListModel : ResponseModel
    {
        public List<LenderMatchModel> MatchedLenderList { get; set; }
        //public string LenderProductType { get; set; } //UNSECURED or GUARANTOR
        public string MatchStatus { get; set; }
        public bool IsDeclinedHomeOwner { get; set; }
        public string RedirectUrl { get; set; }
        public int AwaitingOffers { get; set; }
        public List<string> DeclinedLenders { get; set; }
        public List<string> UnMatchedLenders { get; set; }
        public double LoanAmount { get; set; }
        public int LoanDuration { get; set; }
        public Boolean IsUpdatable { get; set; }
        public LenderMatchListModel()
        {
            MatchedLenderList = new List<LenderMatchModel>();
        }
    }
}