﻿using System.Collections.Generic;

namespace Models
{
    public class MatchedProductResultModel : ResponseModel
    {
        public string LoanApplicationID { get; set; }
        public bool IsMatch { get; set; } = false;
        public bool IsDeclinedHomeOwner { get; set; }
        public string RedirectUrl { get; set; }
        public List<MatchedLenderProductsModel> MatchedProducts { get; set; }

        public MatchedProductResultModel()
        {
            MatchedProducts = new List<MatchedLenderProductsModel>();
        }
    }
}
