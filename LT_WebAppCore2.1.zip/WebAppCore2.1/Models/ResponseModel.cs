﻿namespace Models
{
    public class ResponseModel
    {
        public string Message { get; set; }
        public bool Status { get; set; }
        public string ReturnValue { get; set; }
        public string RequestID { get; set; }
        public string APITokenID { get; set; }
        public string Role { get; set; }
        public string CompanyID { get; set; }
        public bool AuthStatus { get; set; }
    }
}
