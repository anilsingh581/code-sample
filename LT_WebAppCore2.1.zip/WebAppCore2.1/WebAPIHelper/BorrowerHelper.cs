﻿using Logger;
using Microsoft.Extensions.Configuration;
using System.Linq;
using System.Collections.Generic;

using Models;
using RestSharp;

using System;
using System.Net;
using System.Threading.Tasks;
using System.Text;

namespace WebAPIHelper
{
    public  class BorrowerHelper:IBorrower
    {   
        private  Uri ServiceURL = null;
        private  string APIAuthToken = string.Empty;
        private  string getAddressAPIKey = string.Empty;
        IAES aes = null;
        public BorrowerHelper(IConfiguration config,IAES _aes)
        {
            ServiceURL = new Uri(config.GetValue<string>("ServiceURL"));
            APIAuthToken = config.GetValue<string>("LocalUserHostAddress");
            getAddressAPIKey = config.GetValue<string>("LocalUserHostAddress");
            aes = _aes;
        }
              
        /// <summary>
        /// VALIDATE VIEW LOAN APPLICATION - VERIFY/LOAN
        /// THIS METHOD IS USE TO VALIDATE CUSTOMER LOAN DETAIL BY EMAIL LINK.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public  ResponseModel ValidateViewLoanApplication(LoanVerificationReqModel model)
        {
            try
            {
                RestClient client = new RestClient(ServiceURL);
                RestRequest request = new RestRequest("Verify/Loan", Method.POST);
                request.AddJsonBody(model);

                IRestResponse<ResponseModel> response = client.Execute<ResponseModel>(request);
                if (response.StatusCode == HttpStatusCode.OK)
                    return response.Data;
                else if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    ResponseModel res = new ResponseModel();
                    res.Message = "UNAUTHORIZED";
                    return res;
                }
                else
                    return new ResponseModel();
            }
            catch (Exception ex)
            {
                ErrorLog.Error(ex.Message, typeof(BorrowerHelper).Name, "ValidateViewLoanApplication");
                return new ResponseModel();
            }
        }

        /// <summary>
        /// SAVE LOAN APPLICATION - {Loan/New}
        /// THIS METHED IS USED TO SAVE THE LOAN APPLICATION
        /// </summary>
        /// <returns></returns>
        public ResponseModel SaveLoanApplication(BorrowerModel model, string InternalIP, string ExternalIP)
        {
            try
            {
                RestClient client = new RestClient(ServiceURL);
                RestRequest request = new RestRequest("Loan/New", Method.POST);
                request.AddJsonBody(model);

                IRestResponse<ResponseModel> response = client.Execute<ResponseModel>(request);
                if (response.StatusCode == HttpStatusCode.OK)
                    return response.Data;
                else if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    ResponseModel res = new ResponseModel();
                    res.Message = "UNAUTHORIZED";
                    return res;
                }
                else
                    return new ResponseModel();
            }
            catch (Exception ex)
            {
                ErrorLog.Error(ex.Message, typeof(BorrowerHelper).Name, "SaveLoanApplication");
                return new ResponseModel();
            }
        }

        ///// <summary>
        ///// RESUBMIT LOAN APPLICATION RESULT - {Loan/Update}
        ///// </summary>
        public  ResponseModel ResubmitLoanApplicationResult(ModifiedLoanApplicationModel model)
        {
            try
            {
                RestClient client = new RestClient(ServiceURL);
                RestRequest request = new RestRequest("Loan/Update", Method.POST);
                request.AddJsonBody(model);
                IRestResponse<ResponseModel> response = client.Execute<ResponseModel>(request);
                if (response.StatusCode == HttpStatusCode.OK)
                    return response.Data;
                else if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    ResponseModel res = new ResponseModel();
                    res.Message = "UNAUTHORIZED";
                    return res;
                }
                else
                    return new ResponseModel();
            }
            catch (Exception ex)
            {
                ErrorLog.Error(ex.Message, typeof(BorrowerHelper).Name, "ResubmitLoanApplication");
                return new ResponseModel();
            }
        }
     
        /// <summary>
        /// COMPLETE LOAN APPLICATION - Loan/Agreed
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public LoanTubeAPIResponseModel CompleteLoanApplication(string offerID)
        {
            try
            {
              
                RestClient client = new RestClient(ServiceURL);
                RestRequest request = new RestRequest("Loan/Agreed", Method.POST);               
                request.AddJsonBody(offerID);
             
                IRestResponse<LoanTubeAPIResponseModel> response = client.Execute<LoanTubeAPIResponseModel>(request);

                if (response.StatusCode == HttpStatusCode.OK)
                    return response.Data;
                else if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    LoanTubeAPIResponseModel res = new LoanTubeAPIResponseModel();
                    res.Message = "UNAUTHORIZED";
                    return res;
                }
                else
                    return new LoanTubeAPIResponseModel();
            }
            catch (Exception ex)
            {
                ErrorLog.Error(ex.Message, typeof(BorrowerHelper).Name, "CompleteLoanApplication");
                return new LoanTubeAPIResponseModel();
            }
        }
                
       
        public async Task<ResponseModel> UpdateConectiaRequest(LoanAgreement model)
        {
            try
            {
                RestClient client = new RestClient(ServiceURL);
                RestRequest request = new RestRequest("Loan/Conectia", Method.POST);
                request.AddJsonBody(model);
              
                IRestResponse<ResponseModel> response = client.Execute<ResponseModel>(request);
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    Task<ResponseModel> conectiaObj = PushConectiaRequest(model);

                    return response.Data;
                }
                else if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    ResponseModel res = new ResponseModel();
                    res.Message = "UNAUTHORIZED";
                    return res;
                }
                else
                    return new ResponseModel();
            }
            catch (Exception ex)
            {
                ErrorLog.Error(ex.Message, typeof(BorrowerHelper).Name, "UpdateConectiaRequest");
                return new ResponseModel();
            }
        }

       
        public async Task<ResponseModel> PushConectiaRequest(LoanAgreement model)
        {
            ErrorLog.LogMessage($"****** START Conectia Section");
            dynamic conectiaRequestID = (model.LenderReferenceID).Split(new string[] { "-" }, StringSplitOptions.None);
            var conectiaID = conectiaRequestID[0];
            var offerID = conectiaRequestID[1];

            ErrorLog.LogMessage($"Push Conectia Request offerID is : ({offerID}) and the Conectia RequestID is : {conectiaID}");

            var conectiaURL = "p.ashx?o=1570&e="+ model.LenderToken + "&f=pb&r=" + conectiaID + "&t=" + model.LoanApplicationID + "&p=" + model.LoanEMIAmount + "&s3=" + offerID;

            ErrorLog.LogMessage($"PushConectiaRequest Conectia URL : https://mywebconect.com/{conectiaURL}");
            try
            {
                RestClient client = new RestClient("https://mywebconect.com/");
                RestRequest request = new RestRequest(conectiaURL, Method.GET);
                IRestResponse<ResponseModel> response = client.Execute<ResponseModel>(request);
                ErrorLog.LogMessage($"PushConectia Response StatusCode:{response.StatusCode}");
                ErrorLog.LogMessage($"PushConectia Response response.Data::{response.Content}");

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    ErrorLog.LogMessage($"PushConectia Response ResponseUri:{response.ResponseUri}");
                    ErrorLog.LogMessage($"****** START Conectia Section");
                    return response.Data;
                }
                else if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    ResponseModel res = new ResponseModel();
                    res.Message = "UNAUTHORIZED";
                    return res;
                }
                else
                    return new ResponseModel();
            }
            catch (Exception ex)
            {
                ErrorLog.Error("Error Message : " + ex.Message + ", StackTrace : " + ex.StackTrace, typeof(BorrowerHelper).Name, "PushConectiaRequest");
                return new ResponseModel();
            }
        }

        public  LenderMatchListModel GetLoanApplicationResult(string LoanId)
        {
            try
            {


                RestClient client = new RestClient(ServiceURL);
                RestRequest request = new RestRequest("Loan/ShowQuotes/" + LoanId, Method.POST);
               
                IRestResponse<LenderMatchListModel> response = client.Execute<LenderMatchListModel>(request);
               

                response.Data.MatchedLenderList.ForEach(l => l.OfferID = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(l.OfferID)));

                if (response.StatusCode == HttpStatusCode.OK)
                    return response.Data;
                else if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    LenderMatchListModel model = new LenderMatchListModel();
                    model.Message = "UNAUTHORIZED";
                    return model;
                }
                else
                    return new LenderMatchListModel();
            }
            catch (Exception ex)
            {
                ErrorLog.Error(ex.Message, typeof(BorrowerHelper).Name, "LoanApplicationResult");
                return new LenderMatchListModel();
            }
        }

    }
}