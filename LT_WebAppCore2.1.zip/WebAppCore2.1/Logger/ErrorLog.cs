﻿using System.Xml.Serialization;
using System.IO;
using Serilog;
using System;

namespace Logger
{
    public static class ErrorLog
    {
       
        public static void Error(string Message, string ClassName, string MethodName)
        {
            Log.Error($"ERROR : {Message} in Class : {ClassName} , Method : {MethodName}");
        }

        /// <summary>
        /// LOG4NET - ERROR LOG MESSAGE
        /// </summary>
        public static void LogMessage(string Message)
        {
            Log.Information(Message);
        }

        public static void LogException(Exception ex)
        {
            Log.Error(ex.Message);
        }


        
    }
}
